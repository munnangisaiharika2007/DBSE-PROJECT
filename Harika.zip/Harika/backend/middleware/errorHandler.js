const { sendError } = require('../utils/responseHandler');

/**
 * Centralized error handler middleware for Express
 */
function errorHandler(err, req, res, next) {
  console.error('Unhandled Application Error:', err);

  // MySQL Specific Errors
  if (err.code === 'ER_DUP_ENTRY') {
    return sendError(res, 'Duplicate entry found. A record with this unique value already exists.', err.sqlMessage, 409);
  }

  if (err.code === 'ER_NO_REFERENCED_ROW' || err.code === 'ER_NO_REFERENCED_ROW_2') {
    return sendError(res, 'Foreign key constraint failed. Referenced record does not exist.', err.sqlMessage, 400);
  }

  if (err.code === 'ER_ROW_IS_REFERENCED' || err.code === 'ER_ROW_IS_REFERENCED_2') {
    return sendError(res, 'Cannot delete this record because it is referenced by other system data.', err.sqlMessage, 400);
  }

  if (err.code && err.code.startsWith('ER_')) {
    return sendError(res, 'Database error occurred while processing request.', err.sqlMessage || err.message, 500);
  }

  // JWT Errors
  if (err.name === 'JsonWebTokenError') {
    return sendError(res, 'Invalid authentication token', err.message, 401);
  }

  if (err.name === 'TokenExpiredError') {
    return sendError(res, 'Session token expired. Please login again.', err.message, 401);
  }

  // Syntax / Bad JSON Body Error
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return sendError(res, 'Malformed JSON in request body', err.message, 400);
  }

  // Fallback generic 500
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  return sendError(res, message, process.env.NODE_ENV === 'development' ? err.stack : undefined, statusCode);
}

/**
 * 404 Route Not Found handler
 */
function notFoundHandler(req, res, next) {
  return sendError(res, `Resource not found on endpoint: ${req.method} ${req.originalUrl}`, 'Not Found', 404);
}

module.exports = {
  errorHandler,
  notFoundHandler
};
