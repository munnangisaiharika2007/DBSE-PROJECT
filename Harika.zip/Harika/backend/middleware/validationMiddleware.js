const { validationResult, body, param, query } = require('express-validator');
const { sendError } = require('../utils/responseHandler');

/**
 * Middleware that checks for express-validator errors and returns standard JSON error
 */
function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const errorDetails = errors.array().map(e => `${e.path}: ${e.msg}`).join(', ');
    return sendError(res, 'Validation failed', errorDetails, 400);
  }
  next();
}

// User Registration Validation
const validateRegister = [
  body('full_name')
    .trim()
    .notEmpty()
    .withMessage('Full name is required')
    .isLength({ min: 2, max: 100 })
    .withMessage('Name must be between 2 and 100 characters'),
  body('email')
    .trim()
    .isEmail()
    .withMessage('A valid email address is required')
    .normalizeEmail(),
  body('phone')
    .trim()
    .notEmpty()
    .withMessage('Phone number is required')
    .isLength({ min: 8, max: 20 })
    .withMessage('Phone must be 8-20 characters'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long'),
  body('role')
    .optional()
    .isIn(['admin', 'donor', 'user'])
    .withMessage('Role must be admin, donor, or user'),
  handleValidationErrors
];

// User Login Validation
const validateLogin = [
  body('email')
    .trim()
    .isEmail()
    .withMessage('A valid email address is required'),
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  handleValidationErrors
];

// Donor Creation & Update Validation
const validateDonor = [
  body('blood_group')
    .isIn(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'])
    .withMessage('Invalid blood group specified'),
  body('date_of_birth')
    .isISO8601()
    .withMessage('Valid date of birth (YYYY-MM-DD) is required'),
  body('age')
    .isInt({ min: 18, max: 65 })
    .withMessage('Donor must be between 18 and 65 years old'),
  body('gender')
    .isIn(['Male', 'Female', 'Other'])
    .withMessage('Gender must be Male, Female, or Other'),
  body('phone')
    .trim()
    .notEmpty()
    .withMessage('Phone number is required'),
  body('city')
    .trim()
    .notEmpty()
    .withMessage('City is required'),
  body('state')
    .trim()
    .notEmpty()
    .withMessage('State is required'),
  body('pincode')
    .trim()
    .notEmpty()
    .withMessage('Pincode is required'),
  body('latitude')
    .optional({ nullable: true, checkFalsy: true })
    .isFloat({ min: -90, max: 90 })
    .withMessage('Valid latitude is required'),
  body('longitude')
    .optional({ nullable: true, checkFalsy: true })
    .isFloat({ min: -180, max: 180 })
    .withMessage('Valid longitude is required'),
  handleValidationErrors
];

// Blood Bank Validation
const validateBloodBank = [
  body('bank_name')
    .trim()
    .notEmpty()
    .withMessage('Bank name is required'),
  body('license_number')
    .trim()
    .notEmpty()
    .withMessage('License number is required'),
  body('contact_number')
    .trim()
    .notEmpty()
    .withMessage('Contact number is required'),
  body('email')
    .trim()
    .isEmail()
    .withMessage('Valid email is required'),
  body('address')
    .trim()
    .notEmpty()
    .withMessage('Address is required'),
  body('city')
    .trim()
    .notEmpty()
    .withMessage('City is required'),
  body('state')
    .trim()
    .notEmpty()
    .withMessage('State is required'),
  body('pincode')
    .trim()
    .notEmpty()
    .withMessage('Pincode is required'),
  body('latitude')
    .isFloat({ min: -90, max: 90 })
    .withMessage('Valid latitude is required'),
  body('longitude')
    .isFloat({ min: -180, max: 180 })
    .withMessage('Valid longitude is required'),
  handleValidationErrors
];

// Blood Request Validation
const validateBloodRequest = [
  body('patient_name')
    .trim()
    .notEmpty()
    .withMessage('Patient name is required'),
  body('blood_group')
    .isIn(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'])
    .withMessage('Valid blood group is required'),
  body('units_required')
    .isInt({ min: 1, max: 50 })
    .withMessage('Units required must be between 1 and 50'),
  body('hospital_name')
    .trim()
    .notEmpty()
    .withMessage('Hospital name is required'),
  body('hospital_address')
    .trim()
    .notEmpty()
    .withMessage('Hospital address is required'),
  body('city')
    .trim()
    .notEmpty()
    .withMessage('City is required'),
  body('state')
    .trim()
    .notEmpty()
    .withMessage('State is required'),
  body('pincode')
    .trim()
    .notEmpty()
    .withMessage('Pincode is required'),
  body('emergency_level')
    .isIn(['Normal', 'Urgent', 'Critical'])
    .withMessage('Emergency level must be Normal, Urgent, or Critical'),
  body('required_date')
    .isISO8601()
    .withMessage('Valid required date (YYYY-MM-DD) is required'),
  body('contact_number')
    .trim()
    .notEmpty()
    .withMessage('Contact number is required'),
  handleValidationErrors
];

module.exports = {
  handleValidationErrors,
  validateRegister,
  validateLogin,
  validateDonor,
  validateBloodBank,
  validateBloodRequest
};
