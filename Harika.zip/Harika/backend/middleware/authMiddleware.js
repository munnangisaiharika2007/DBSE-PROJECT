const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const { sendError } = require('../utils/responseHandler');

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_blood_bank_jwt_key_2026';

/**
 * Authenticate incoming request via JWT Bearer Token
 */
async function authenticateUser(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return sendError(res, 'Authentication required', 'No token provided', 401);
    }

    const token = authHeader.split(' ')[1];
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (err) {
      return sendError(res, 'Invalid or expired session', 'Token verification failed', 401);
    }

    // Verify user still exists in database
    const [rows] = await pool.query(
      'SELECT user_id, full_name, email, phone, role FROM users WHERE user_id = ?',
      [decoded.user_id]
    );

    if (rows.length === 0) {
      return sendError(res, 'User account no longer exists', 'Unauthorized', 401);
    }

    req.user = rows[0];
    next();
  } catch (error) {
    return sendError(res, 'Authentication error', error.message, 500);
  }
}

/**
 * Authorize only users with admin role
 */
function authorizeAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return sendError(res, 'Access denied', 'Admin privileges required', 403);
  }
  next();
}

/**
 * Authorize donor or admin
 */
function authorizeDonor(req, res, next) {
  if (!req.user || (req.user.role !== 'donor' && req.user.role !== 'admin')) {
    return sendError(res, 'Access denied', 'Donor access required', 403);
  }
  next();
}

/**
 * Authorize specific roles
 */
function authorizeRoles(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return sendError(res, 'Access forbidden', `Required role: ${allowedRoles.join(' or ')}`, 403);
    }
    next();
  };
}

module.exports = {
  authenticateUser,
  authorizeAdmin,
  authorizeDonor,
  authorizeRoles,
  JWT_SECRET
};
