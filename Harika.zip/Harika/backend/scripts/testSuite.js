const http = require('http');

function request(method, path, body = null, token = null) {
  return new Promise((resolve, reject) => {
    const dataString = body ? JSON.stringify(body) : null;
    const headers = {
      'Content-Type': 'application/json'
    };
    if (dataString) {
      headers['Content-Length'] = Buffer.byteLength(dataString);
    }
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const req = http.request({
      hostname: 'localhost',
      port: 5000,
      path,
      method,
      headers
    }, (res) => {
      let responseBody = '';
      res.on('data', chunk => responseBody += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(responseBody);
          resolve({ status: res.statusCode, data: parsed });
        } catch (e) {
          resolve({ status: res.statusCode, text: responseBody });
        }
      });
    });

    req.on('error', reject);
    if (dataString) {
      req.write(dataString);
    }
    req.end();
  });
}

async function runTestSuite() {
  console.log('🧪 ==========================================');
  console.log('🧪 Starting Full System Integration Test Suite');
  console.log('🧪 ==========================================');

  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName} - ${details}`);
      failed++;
    }
  }

  try {
    // 1. Health Check
    const health = await request('GET', '/api/health');
    assert(health.status === 200 && health.data.status === 'online', 'Health Check Endpoint /api/health');

    // 2. Admin Login
    const adminLogin = await request('POST', '/api/auth/login', {
      email: 'admin@bloodbank.org',
      password: 'Password123'
    });
    assert(adminLogin.status === 200 && adminLogin.data.data.token, 'Admin Login Authentication');
    const adminToken = adminLogin.data.data?.token;

    // 3. Donor Login
    const donorLogin = await request('POST', '/api/auth/login', {
      email: 'rahul.sharma@gmail.com',
      password: 'Password123'
    });
    assert(donorLogin.status === 200 && donorLogin.data.data.user.role === 'donor', 'Donor Login Authentication & Role');
    const donorToken = donorLogin.data.data?.token;

    // 4. Session Info /auth/me
    const me = await request('GET', '/api/auth/me', null, donorToken);
    assert(me.status === 200 && me.data.data.donorProfile !== null, 'Fetch Current User Session with Donor Profile');

    // 5. Admin Dashboard Statistics
    const stats = await request('GET', '/api/dashboard/stats', null, adminToken);
    assert(
      stats.status === 200 &&
      stats.data.data.summary.total_users >= 15 &&
      stats.data.data.summary.total_donors >= 10 &&
      stats.data.data.summary.total_blood_banks >= 5,
      'Admin Dashboard MySQL Aggregations & KPIs'
    );

    // 6. Donors Directory
    const donors = await request('GET', '/api/donors');
    assert(donors.status === 200 && Array.isArray(donors.data.data) && donors.data.data.length >= 10, 'Retrieve Donors Directory');

    // 7. Donor Search & Geolocation Filter
    const donorSearch = await request('GET', '/api/donors/search?blood_group=O%2B&city=Hyderabad');
    assert(donorSearch.status === 200 && donorSearch.data.data.length > 0, 'Filter Donors by Blood Group O+ in Hyderabad');

    // 8. Haversine Spatial Donors Nearby
    const nearbyDonors = await request('GET', '/api/donors/nearby?lat=17.415582&lng=78.435821&radius=50');
    assert(
      nearbyDonors.status === 200 &&
      Array.isArray(nearbyDonors.data.data) &&
      nearbyDonors.data.data.length > 0 &&
      nearbyDonors.data.data[0].distance_km !== undefined,
      'Haversine Spherical Distance for Nearby Donors'
    );

    // 9. Blood Banks & Nearby Banks
    const banks = await request('GET', '/api/blood-banks');
    assert(banks.status === 200 && banks.data.data.length >= 5, 'Retrieve Registered Blood Banks');

    const nearbyBanks = await request('GET', '/api/blood-banks/nearby?lat=17.415582&lng=78.435821&radius=50');
    assert(nearbyBanks.status === 200 && nearbyBanks.data.data[0].distance_km !== undefined, 'Nearby Blood Banks with Haversine Distance');

    // 10. Inventory Retrieval
    const inventory = await request('GET', '/api/inventory');
    assert(inventory.status === 200 && inventory.data.data.length >= 40, 'Retrieve Complete Blood Inventory across Centers');

    // 11. Create & Manage Blood Request
    const testReq = await request('POST', '/api/requests', {
      patient_name: 'Test Patient Sharma',
      blood_group: 'B+',
      units_required: 2,
      hospital_name: 'Apollo Hospital',
      hospital_address: 'Jubilee Hills',
      city: 'Hyderabad',
      state: 'Telangana',
      pincode: '500033',
      emergency_level: 'Urgent',
      required_date: new Date().toISOString().split('T')[0],
      contact_number: '+91 99999 88888',
      additional_notes: 'Automated test suite request'
    }, donorToken);
    assert(testReq.status === 201 && testReq.data.data.request_id, 'Submit New Blood Request');
    const createdRequestId = testReq.data.data?.request_id;

    // 12. Admin Updates Request Status
    if (createdRequestId) {
      const updateStatus = await request('PUT', `/api/requests/${createdRequestId}/status`, { status: 'Approved' }, adminToken);
      assert(updateStatus.status === 200, 'Admin Approves Blood Request');
    }

    // 13. Transactional Donation & Inventory Update
    const donationRes = await request('POST', '/api/donations', {
      donor_id: 1,
      blood_bank_id: 1,
      donation_date: new Date().toISOString().split('T')[0],
      blood_group: 'O+',
      units_donated: 1,
      notes: 'Automated integration test donation'
    }, adminToken);
    assert(donationRes.status === 201, 'Record Donation with Automatic Inventory Increment');

    // 14. Unauthorized Access Rejection (Security check)
    const unauthorized = await request('GET', '/api/users');
    assert(unauthorized.status === 401, 'Reject Access to Protected Endpoint Without Token');

    const forbidden = await request('GET', '/api/users', null, donorToken);
    assert(forbidden.status === 403, 'Reject Non-Admin Access to Admin Users Management');

  } catch (err) {
    console.error('Fatal Test Exception:', err);
    failed++;
  }

  console.log('🧪 ==========================================');
  console.log(`🧪 Results: ${passed} PASSED | ${failed} FAILED`);
  console.log('🧪 ==========================================');

  if (failed === 0) {
    console.log('🎉 ALL INTEGRATION TESTS PASSED PERFECTLY!');
  }
}

runTestSuite();
