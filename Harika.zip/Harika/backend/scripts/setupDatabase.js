const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

async function setupDatabase() {
  console.log('--- Initializing Blood Bank Database Setup ---');
  const host = process.env.DB_HOST || 'localhost';
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || '';
  const port = parseInt(process.env.DB_PORT, 10) || 3306;

  let connection;
  try {
    // 1. Connect without database to create it if needed
    connection = await mysql.createConnection({
      host,
      user,
      password,
      port,
      multipleStatements: true
    });

    console.log(`Connected to MySQL Server at ${host}:${port} as ${user}`);

    // Read schema.sql
    const schemaPath = path.join(__dirname, '../../database/schema.sql');
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');

    console.log('Executing database/schema.sql...');
    await connection.query(schemaSql);
    console.log('Schema executed successfully. Database & tables created.');

    // Read sample_data.sql
    const sampleDataPath = path.join(__dirname, '../../database/sample_data.sql');
    const sampleDataSql = fs.readFileSync(sampleDataPath, 'utf8');

    console.log('Executing database/sample_data.sql...');
    await connection.query(sampleDataSql);
    console.log('Sample data populated successfully.');

    console.log('--- Database Setup Completed Successfully! ---');
  } catch (error) {
    console.error('Database setup failed:', error.message);
    process.exitCode = 1;
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

if (require.main === module) {
  setupDatabase();
}

module.exports = setupDatabase;
