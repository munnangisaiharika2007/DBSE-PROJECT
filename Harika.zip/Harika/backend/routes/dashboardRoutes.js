const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');

// Dashboard statistics (can be accessed by admin or authenticated user for dashboard widgets)
router.get('/stats', authenticateUser, dashboardController.getDashboardStats);

module.exports = router;
