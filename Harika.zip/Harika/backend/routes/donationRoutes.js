const express = require('express');
const router = express.Router();
const donationController = require('../controllers/donationController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');

router.get('/', authenticateUser, donationController.getAllDonations);
router.get('/donor/:donorId', authenticateUser, donationController.getDonationsByDonorId);
router.post('/', authenticateUser, authorizeAdmin, donationController.createDonation);

module.exports = router;
