const express = require('express');
const router = express.Router();
const bloodBankController = require('../controllers/bloodBankController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');
const { validateBloodBank } = require('../middleware/validationMiddleware');

router.get('/nearby', bloodBankController.getNearbyBloodBanks);
router.get('/', bloodBankController.getAllBloodBanks);
router.get('/:id', bloodBankController.getBloodBankById);

router.post('/', authenticateUser, authorizeAdmin, validateBloodBank, bloodBankController.createBloodBank);
router.put('/:id', authenticateUser, authorizeAdmin, bloodBankController.updateBloodBank);
router.delete('/:id', authenticateUser, authorizeAdmin, bloodBankController.deleteBloodBank);

module.exports = router;
