const express = require('express');
const router = express.Router();
const inventoryController = require('../controllers/inventoryController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');

router.get('/', inventoryController.getAllInventory);
router.get('/:bloodBankId', inventoryController.getInventoryByBloodBank);

router.post('/', authenticateUser, authorizeAdmin, inventoryController.createOrUpdateInventory);
router.put('/:id', authenticateUser, authorizeAdmin, inventoryController.updateInventory);
router.delete('/:id', authenticateUser, authorizeAdmin, inventoryController.deleteInventory);

module.exports = router;
