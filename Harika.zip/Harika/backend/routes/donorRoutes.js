const express = require('express');
const router = express.Router();
const donorController = require('../controllers/donorController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');
const { validateDonor } = require('../middleware/validationMiddleware');

// Specific routes before param :id routes
router.get('/search', donorController.searchDonors);
router.get('/nearby', donorController.getNearbyDonors);

router.get('/', donorController.getAllDonors);
router.get('/:id', donorController.getDonorById);

router.post('/', authenticateUser, validateDonor, donorController.createDonor);
router.put('/:id', authenticateUser, donorController.updateDonor);
router.delete('/:id', authenticateUser, authorizeAdmin, donorController.deleteDonor);

module.exports = router;
