const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');

router.get('/', authenticateUser, authorizeAdmin, userController.getAllUsers);
router.put('/:id', authenticateUser, authorizeAdmin, userController.updateUser);
router.delete('/:id', authenticateUser, authorizeAdmin, userController.deleteUser);

module.exports = router;
