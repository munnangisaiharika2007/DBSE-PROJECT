const express = require('express');
const router = express.Router();
const requestController = require('../controllers/requestController');
const { authenticateUser, authorizeAdmin } = require('../middleware/authMiddleware');
const { validateBloodRequest } = require('../middleware/validationMiddleware');

router.get('/', authenticateUser, requestController.getAllRequests);
router.get('/:id', authenticateUser, requestController.getRequestById);

router.post('/', authenticateUser, validateBloodRequest, requestController.createRequest);
router.put('/:id/status', authenticateUser, authorizeAdmin, requestController.updateRequestStatus);
router.put('/:id', authenticateUser, requestController.updateRequest);
router.delete('/:id', authenticateUser, requestController.deleteRequest);

module.exports = router;
