/**
 * Standardized API response format helpers
 */

function sendSuccess(res, message, data = null, statusCode = 200) {
  return res.status(statusCode).json({
    success: true,
    message,
    data: data !== null ? data : {}
  });
}

function sendError(res, message, error = null, statusCode = 500) {
  return res.status(statusCode).json({
    success: false,
    message,
    error: error || message
  });
}

module.exports = {
  sendSuccess,
  sendError
};
