const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const { testConnection } = require('./config/db');
const { errorHandler, notFoundHandler } = require('./middleware/errorHandler');

// Import route modules
const authRoutes = require('./routes/authRoutes');
const donorRoutes = require('./routes/donorRoutes');
const bloodBankRoutes = require('./routes/bloodBankRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const requestRoutes = require('./routes/requestRoutes');
const donationRoutes = require('./routes/donationRoutes');
const userRoutes = require('./routes/userRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Enable Cross-Origin Resource Sharing (CORS)
app.use(cors());

// Parse incoming JSON and URL-encoded payloads
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend static assets
const frontendDir = path.join(__dirname, '../frontend');
app.use(express.static(frontendDir));

// Mount REST API routes
app.use('/api/auth', authRoutes);
app.use('/api/donors', donorRoutes);
app.use('/api/blood-banks', bloodBankRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/requests', requestRoutes);
app.use('/api/donations', donationRoutes);
app.use('/api/users', userRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    service: 'Blood Bank and Donor Location System API'
  });
});

// For any other non-API GET request, serve index.html (SPA/static fallback)
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) {
    return next();
  }
  res.sendFile(path.join(frontendDir, 'index.html'));
});

// 404 handler for unrecognized API routes
app.use(notFoundHandler);

// Centralized Express error handler
app.use(errorHandler);

// Start Server and verify DB connection
async function startServer() {
  const isConnected = await testConnection();
  if (!isConnected) {
    console.warn('⚠️ Server is starting, but MySQL database connection failed. Check your DB credentials in .env');
  }

  const server = app.listen(PORT, () => {
    console.log(`🚀 Blood Bank System Server running on: http://localhost:${PORT}`);
    console.log(`🌐 Frontend accessible at: http://localhost:${PORT}/index.html`);
    console.log(`📡 REST API base URL: http://localhost:${PORT}/api`);
  });

  return server;
}

if (require.main === module) {
  startServer();
}

module.exports = { app, startServer };
