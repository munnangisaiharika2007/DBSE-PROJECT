const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');

/**
 * Admin: Get all registered users
 */
async function getAllUsers(req, res, next) {
  try {
    const { role, search } = req.query;

    let query = `
      SELECT 
        u.user_id,
        u.full_name,
        u.email,
        u.phone,
        u.role,
        u.created_at,
        u.updated_at,
        d.donor_id,
        d.blood_group,
        d.city,
        d.availability_status
      FROM users u
      LEFT JOIN donors d ON u.user_id = d.user_id
      WHERE 1=1
    `;
    const params = [];

    if (role && role !== 'All') {
      query += ' AND u.role = ?';
      params.push(role);
    }
    if (search) {
      query += ' AND (LOWER(u.full_name) LIKE LOWER(?) OR LOWER(u.email) LIKE LOWER(?) OR u.phone LIKE ?)';
      params.push(`%${search.trim()}%`, `%${search.trim()}%`, `%${search.trim()}%`);
    }

    query += ' ORDER BY u.created_at DESC';

    const [users] = await pool.query(query, params);

    return sendSuccess(res, 'Users retrieved successfully', users);
  } catch (error) {
    next(error);
  }
}

/**
 * Admin: Update user details or role
 */
async function updateUser(req, res, next) {
  try {
    const userId = parseInt(req.params.id, 10);
    const { full_name, email, phone, role } = req.body;

    const updates = [];
    const params = [];

    if (full_name !== undefined) { updates.push('full_name = ?'); params.push(full_name); }
    if (email !== undefined) { updates.push('email = ?'); params.push(email.toLowerCase()); }
    if (phone !== undefined) { updates.push('phone = ?'); params.push(phone); }
    if (role !== undefined) { updates.push('role = ?'); params.push(role); }

    if (updates.length === 0) {
      return sendError(res, 'No update fields provided', 'Bad request', 400);
    }

    params.push(userId);
    const [result] = await pool.query(
      `UPDATE users SET ${updates.join(', ')} WHERE user_id = ?`,
      params
    );

    if (result.affectedRows === 0) {
      return sendError(res, 'User not found', 'No user found with this ID', 404);
    }

    return sendSuccess(res, 'User updated successfully');
  } catch (error) {
    next(error);
  }
}

/**
 * Admin: Delete user
 */
async function deleteUser(req, res, next) {
  try {
    const userId = parseInt(req.params.id, 10);

    // Prevent deleting own admin account
    if (req.user.user_id === userId) {
      return sendError(res, 'Cannot delete your own admin account', 'Self-deletion forbidden', 400);
    }

    const [result] = await pool.query('DELETE FROM users WHERE user_id = ?', [userId]);

    if (result.affectedRows === 0) {
      return sendError(res, 'User not found', 'No user found with this ID', 404);
    }

    return sendSuccess(res, 'User account and associated records deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllUsers,
  updateUser,
  deleteUser
};
