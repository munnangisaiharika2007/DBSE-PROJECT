const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');
const { calculateHaversineDistance } = require('../utils/distance');

/**
 * Get all blood banks with optional filters and total inventory count
 */
async function getAllBloodBanks(req, res, next) {
  try {
    const { city, status, search } = req.query;

    let query = `
      SELECT 
        bb.blood_bank_id,
        bb.bank_name,
        bb.license_number,
        bb.contact_number,
        bb.email,
        bb.address,
        bb.city,
        bb.state,
        bb.pincode,
        bb.latitude,
        bb.longitude,
        bb.opening_time,
        bb.closing_time,
        bb.emergency_available,
        bb.status,
        bb.created_at,
        COALESCE(SUM(bi.units_available), 0) AS total_units_available
      FROM blood_banks bb
      LEFT JOIN blood_inventory bi ON bb.blood_bank_id = bi.blood_bank_id
      WHERE 1=1
    `;
    const params = [];

    if (city) {
      query += ' AND LOWER(bb.city) = LOWER(?)';
      params.push(city.trim());
    }
    if (status) {
      query += ' AND bb.status = ?';
      params.push(status);
    }
    if (search) {
      query += ' AND (LOWER(bb.bank_name) LIKE LOWER(?) OR LOWER(bb.city) LIKE LOWER(?) OR bb.pincode LIKE ?)';
      params.push(`%${search.trim()}%`, `%${search.trim()}%`, `%${search.trim()}%`);
    }

    query += ' GROUP BY bb.blood_bank_id ORDER BY bb.bank_name ASC';

    const [banks] = await pool.query(query, params);

    return sendSuccess(res, 'Blood banks retrieved successfully', banks);
  } catch (error) {
    next(error);
  }
}

/**
 * Get blood bank by ID with full inventory breakdown
 */
async function getBloodBankById(req, res, next) {
  try {
    const bankId = parseInt(req.params.id, 10);

    const [banks] = await pool.query(
      `SELECT * FROM blood_banks WHERE blood_bank_id = ?`,
      [bankId]
    );

    if (banks.length === 0) {
      return sendError(res, 'Blood bank not found', 'No blood bank found with this ID', 404);
    }

    const bloodBank = banks[0];

    // Get inventory details
    const [inventory] = await pool.query(
      `SELECT inventory_id, blood_group, units_available, minimum_required_units, last_updated,
              CASE
                WHEN units_available = 0 THEN 'Out of Stock'
                WHEN units_available < (minimum_required_units / 2) THEN 'Critical'
                WHEN units_available < minimum_required_units THEN 'Low Stock'
                ELSE 'Available'
              END AS stock_status
       FROM blood_inventory
       WHERE blood_bank_id = ?
       ORDER BY blood_group ASC`,
      [bankId]
    );

    bloodBank.inventory = inventory;

    return sendSuccess(res, 'Blood bank details retrieved', bloodBank);
  } catch (error) {
    next(error);
  }
}

/**
 * Get nearby blood banks within radius using Haversine formula
 */
async function getNearbyBloodBanks(req, res, next) {
  try {
    const { lat, lng, radius = 50, blood_group } = req.query;

    if (!lat || !lng || isNaN(lat) || isNaN(lng)) {
      return sendError(res, 'Valid latitude and longitude are required', 'Missing coordinates', 400);
    }

    const userLat = parseFloat(lat);
    const userLng = parseFloat(lng);
    const maxRadius = parseFloat(radius);

    let query = `
      SELECT 
        bb.blood_bank_id,
        bb.bank_name,
        bb.license_number,
        bb.contact_number,
        bb.email,
        bb.address,
        bb.city,
        bb.state,
        bb.pincode,
        bb.latitude,
        bb.longitude,
        bb.opening_time,
        bb.closing_time,
        bb.emergency_available,
        bb.status,
        COALESCE(SUM(bi.units_available), 0) AS total_units_available
      FROM blood_banks bb
      LEFT JOIN blood_inventory bi ON bb.blood_bank_id = bi.blood_bank_id
      WHERE bb.status = 'Active'
    `;
    const params = [];

    if (blood_group && blood_group !== 'All') {
      query += ' AND bi.blood_group = ? AND bi.units_available > 0';
      params.push(blood_group);
    }

    query += ' GROUP BY bb.blood_bank_id';

    const [banks] = await pool.query(query, params);

    const nearbyBanks = banks
      .map(bank => {
        const distance = calculateHaversineDistance(
          userLat,
          userLng,
          parseFloat(bank.latitude),
          parseFloat(bank.longitude)
        );
        return {
          ...bank,
          distance_km: distance
        };
      })
      .filter(bank => bank.distance_km <= maxRadius)
      .sort((a, b) => a.distance_km - b.distance_km);

    return sendSuccess(res, 'Nearby blood banks retrieved', nearbyBanks);
  } catch (error) {
    next(error);
  }
}

/**
 * Admin: Create new blood bank
 */
async function createBloodBank(req, res, next) {
  const connection = await pool.getConnection();
  try {
    const {
      bank_name,
      license_number,
      contact_number,
      email,
      address,
      city,
      state,
      pincode,
      latitude,
      longitude,
      opening_time = '08:00:00',
      closing_time = '20:00:00',
      emergency_available = true,
      status = 'Active'
    } = req.body;

    await connection.beginTransaction();

    const [result] = await connection.query(
      `INSERT INTO blood_banks (
        bank_name, license_number, contact_number, email, address,
        city, state, pincode, latitude, longitude,
        opening_time, closing_time, emergency_available, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        bank_name,
        license_number,
        contact_number,
        email,
        address,
        city,
        state,
        pincode,
        latitude,
        longitude,
        opening_time,
        closing_time,
        emergency_available,
        status
      ]
    );

    const newBankId = result.insertId;

    // Automatically initialize inventory for all 8 standard blood groups
    const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    for (const bg of bloodGroups) {
      await connection.query(
        `INSERT INTO blood_inventory (blood_bank_id, blood_group, units_available, minimum_required_units)
         VALUES (?, ?, 0, 10)`,
        [newBankId, bg]
      );
    }

    await connection.commit();

    return sendSuccess(
      res,
      'Blood bank registered successfully with default inventory',
      { blood_bank_id: newBankId },
      201
    );
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
}

/**
 * Admin: Update blood bank
 */
async function updateBloodBank(req, res, next) {
  try {
    const bankId = parseInt(req.params.id, 10);
    const {
      bank_name,
      license_number,
      contact_number,
      email,
      address,
      city,
      state,
      pincode,
      latitude,
      longitude,
      opening_time,
      closing_time,
      emergency_available,
      status
    } = req.body;

    const updates = [];
    const params = [];

    if (bank_name !== undefined) { updates.push('bank_name = ?'); params.push(bank_name); }
    if (license_number !== undefined) { updates.push('license_number = ?'); params.push(license_number); }
    if (contact_number !== undefined) { updates.push('contact_number = ?'); params.push(contact_number); }
    if (email !== undefined) { updates.push('email = ?'); params.push(email); }
    if (address !== undefined) { updates.push('address = ?'); params.push(address); }
    if (city !== undefined) { updates.push('city = ?'); params.push(city); }
    if (state !== undefined) { updates.push('state = ?'); params.push(state); }
    if (pincode !== undefined) { updates.push('pincode = ?'); params.push(pincode); }
    if (latitude !== undefined) { updates.push('latitude = ?'); params.push(latitude); }
    if (longitude !== undefined) { updates.push('longitude = ?'); params.push(longitude); }
    if (opening_time !== undefined) { updates.push('opening_time = ?'); params.push(opening_time); }
    if (closing_time !== undefined) { updates.push('closing_time = ?'); params.push(closing_time); }
    if (emergency_available !== undefined) { updates.push('emergency_available = ?'); params.push(emergency_available); }
    if (status !== undefined) { updates.push('status = ?'); params.push(status); }

    if (updates.length === 0) {
      return sendError(res, 'No update fields provided', 'Bad request', 400);
    }

    params.push(bankId);
    const [result] = await pool.query(
      `UPDATE blood_banks SET ${updates.join(', ')} WHERE blood_bank_id = ?`,
      params
    );

    if (result.affectedRows === 0) {
      return sendError(res, 'Blood bank not found', 'No blood bank found with this ID', 404);
    }

    return sendSuccess(res, 'Blood bank updated successfully');
  } catch (error) {
    next(error);
  }
}

/**
 * Admin: Delete blood bank
 */
async function deleteBloodBank(req, res, next) {
  try {
    const bankId = parseInt(req.params.id, 10);

    const [result] = await pool.query('DELETE FROM blood_banks WHERE blood_bank_id = ?', [bankId]);
    if (result.affectedRows === 0) {
      return sendError(res, 'Blood bank not found', 'No blood bank found with this ID', 404);
    }

    return sendSuccess(res, 'Blood bank and associated inventory deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllBloodBanks,
  getBloodBankById,
  getNearbyBloodBanks,
  createBloodBank,
  updateBloodBank,
  deleteBloodBank
};
