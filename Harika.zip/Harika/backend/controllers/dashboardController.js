const { pool } = require('../config/db');
const { sendSuccess } = require('../utils/responseHandler');

/**
 * Get comprehensive dashboard statistics and chart datasets directly from MySQL
 */
async function getDashboardStats(req, res, next) {
  try {
    // 1. Overall counts summary
    const [counts] = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM users) AS total_users,
        (SELECT COUNT(*) FROM donors) AS total_donors,
        (SELECT COUNT(*) FROM donors WHERE availability_status = 'Available' AND medical_eligibility = 'Eligible') AS available_donors,
        (SELECT COUNT(*) FROM blood_banks WHERE status = 'Active') AS total_blood_banks,
        (SELECT COALESCE(SUM(units_available), 0) FROM blood_inventory) AS total_blood_units,
        (SELECT COUNT(*) FROM blood_requests WHERE status = 'Pending') AS pending_requests,
        (SELECT COUNT(*) FROM blood_requests WHERE emergency_level = 'Critical' AND status = 'Pending') AS critical_requests,
        (SELECT COUNT(*) FROM donations) AS total_donations
    `);

    // 2. Blood group distribution across donors
    const [bloodGroupDist] = await pool.query(`
      SELECT 
        blood_group,
        COUNT(donor_id) AS donor_count
      FROM donors
      GROUP BY blood_group
      ORDER BY FIELD(blood_group, 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')
    `);

    // 3. Blood inventory units available by blood group
    const [inventoryByGroup] = await pool.query(`
      SELECT 
        blood_group,
        COALESCE(SUM(units_available), 0) AS total_units,
        COALESCE(SUM(minimum_required_units), 0) AS total_required
      FROM blood_inventory
      GROUP BY blood_group
      ORDER BY FIELD(blood_group, 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')
    `);

    // 4. Monthly donations (past 6 months)
    const [monthlyDonations] = await pool.query(`
      SELECT 
        DATE_FORMAT(donation_date, '%b %Y') AS month_label,
        COUNT(donation_id) AS donation_count,
        COALESCE(SUM(units_donated), 0) AS units_donated
      FROM donations
      WHERE donation_date >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
      GROUP BY DATE_FORMAT(donation_date, '%b %Y'), YEAR(donation_date), MONTH(donation_date)
      ORDER BY YEAR(donation_date) ASC, MONTH(donation_date) ASC
    `);

    // 5. Blood requests breakdown by status
    const [requestsByStatus] = await pool.query(`
      SELECT 
        status,
        COUNT(request_id) AS count
      FROM blood_requests
      GROUP BY status
    `);

    // 6. Emergency level breakdown for pending requests
    const [requestsByEmergency] = await pool.query(`
      SELECT 
        emergency_level,
        COUNT(request_id) AS count
      FROM blood_requests
      GROUP BY emergency_level
    `);

    // 7. Recent blood requests for quick dashboard table
    const [recentRequests] = await pool.query(`
      SELECT 
        br.request_id,
        br.patient_name,
        br.blood_group,
        br.units_required,
        br.hospital_name,
        br.city,
        br.emergency_level,
        br.status,
        br.required_date
      FROM blood_requests br
      ORDER BY br.created_at DESC
      LIMIT 5
    `);

    // 8. Recent donations
    const [recentDonations] = await pool.query(`
      SELECT 
        d.donation_id,
        u.full_name AS donor_name,
        d.blood_group,
        d.units_donated,
        bb.bank_name,
        d.donation_date
      FROM donations d
      INNER JOIN donors dn ON d.donor_id = dn.donor_id
      INNER JOIN users u ON dn.user_id = u.user_id
      INNER JOIN blood_banks bb ON d.blood_bank_id = bb.blood_bank_id
      ORDER BY d.donation_date DESC, d.donation_id DESC
      LIMIT 5
    `);

    const stats = {
      summary: counts[0],
      bloodGroupDistribution: bloodGroupDist,
      inventoryByGroup,
      monthlyDonations,
      requestsByStatus,
      requestsByEmergency,
      recentRequests,
      recentDonations
    };

    return sendSuccess(res, 'Dashboard statistics loaded successfully', stats);
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getDashboardStats
};
