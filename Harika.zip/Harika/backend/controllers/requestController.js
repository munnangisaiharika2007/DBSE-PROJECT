const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');

/**
 * Get all blood requests (admins see all, regular users see their own, donors see pending requests)
 */
async function getAllRequests(req, res, next) {
  try {
    const { status, emergency_level, blood_group, city, user_only } = req.query;

    let query = `
      SELECT 
        br.request_id,
        br.requester_id,
        u.full_name AS requester_name,
        u.email AS requester_email,
        br.patient_name,
        br.blood_group,
        br.units_required,
        br.hospital_name,
        br.hospital_address,
        br.city,
        br.state,
        br.pincode,
        br.emergency_level,
        br.required_date,
        br.contact_number,
        br.additional_notes,
        br.status,
        br.created_at,
        br.updated_at
      FROM blood_requests br
      INNER JOIN users u ON br.requester_id = u.user_id
      WHERE 1=1
    `;
    const params = [];

    // If user explicitly asks for own requests, or is a regular user not on public view
    if (user_only === 'true' && req.user) {
      query += ' AND br.requester_id = ?';
      params.push(req.user.user_id);
    } else if (req.user && req.user.role === 'user' && !req.query.public_view) {
      // Regular user view defaults to their own requests
      query += ' AND br.requester_id = ?';
      params.push(req.user.user_id);
    }

    if (status && status !== 'All') {
      query += ' AND br.status = ?';
      params.push(status);
    }
    if (emergency_level && emergency_level !== 'All') {
      query += ' AND br.emergency_level = ?';
      params.push(emergency_level);
    }
    if (blood_group && blood_group !== 'All') {
      query += ' AND br.blood_group = ?';
      params.push(blood_group);
    }
    if (city) {
      query += ' AND LOWER(br.city) = LOWER(?)';
      params.push(city.trim());
    }

    query += ' ORDER BY FIELD(br.emergency_level, "Critical", "Urgent", "Normal"), br.created_at DESC';

    const [requests] = await pool.query(query, params);

    return sendSuccess(res, 'Blood requests retrieved successfully', requests);
  } catch (error) {
    next(error);
  }
}

/**
 * Get blood request by ID
 */
async function getRequestById(req, res, next) {
  try {
    const requestId = parseInt(req.params.id, 10);

    const [requests] = await pool.query(
      `SELECT 
        br.*,
        u.full_name AS requester_name,
        u.email AS requester_email
      FROM blood_requests br
      INNER JOIN users u ON br.requester_id = u.user_id
      WHERE br.request_id = ?`,
      [requestId]
    );

    if (requests.length === 0) {
      return sendError(res, 'Request not found', 'No blood request found with this ID', 404);
    }

    return sendSuccess(res, 'Blood request retrieved', requests[0]);
  } catch (error) {
    next(error);
  }
}

/**
 * Create a new blood request
 */
async function createRequest(req, res, next) {
  try {
    const {
      patient_name,
      blood_group,
      units_required,
      hospital_name,
      hospital_address,
      city,
      state,
      pincode,
      emergency_level = 'Normal',
      required_date,
      contact_number,
      additional_notes
    } = req.body;

    const requester_id = req.user.user_id;

    const [result] = await pool.query(
      `INSERT INTO blood_requests (
        requester_id, patient_name, blood_group, units_required,
        hospital_name, hospital_address, city, state, pincode,
        emergency_level, required_date, contact_number, additional_notes, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')`,
      [
        requester_id,
        patient_name,
        blood_group,
        units_required,
        hospital_name,
        hospital_address,
        city,
        state,
        pincode,
        emergency_level,
        required_date,
        contact_number,
        additional_notes || null
      ]
    );

    return sendSuccess(
      res,
      'Blood request submitted successfully',
      { request_id: result.insertId },
      201
    );
  } catch (error) {
    next(error);
  }
}

/**
 * Update request details (requester or admin)
 */
async function updateRequest(req, res, next) {
  try {
    const requestId = parseInt(req.params.id, 10);

    const [existing] = await pool.query(
      'SELECT requester_id, status FROM blood_requests WHERE request_id = ?',
      [requestId]
    );

    if (existing.length === 0) {
      return sendError(res, 'Request not found', 'No request with this ID', 404);
    }

    if (req.user.role !== 'admin' && existing[0].requester_id !== req.user.user_id) {
      return sendError(res, 'Unauthorized', 'You can only update your own requests', 403);
    }

    const {
      patient_name,
      blood_group,
      units_required,
      hospital_name,
      hospital_address,
      city,
      state,
      pincode,
      emergency_level,
      required_date,
      contact_number,
      additional_notes,
      status
    } = req.body;

    const updates = [];
    const params = [];

    if (patient_name !== undefined) { updates.push('patient_name = ?'); params.push(patient_name); }
    if (blood_group !== undefined) { updates.push('blood_group = ?'); params.push(blood_group); }
    if (units_required !== undefined) { updates.push('units_required = ?'); params.push(units_required); }
    if (hospital_name !== undefined) { updates.push('hospital_name = ?'); params.push(hospital_name); }
    if (hospital_address !== undefined) { updates.push('hospital_address = ?'); params.push(hospital_address); }
    if (city !== undefined) { updates.push('city = ?'); params.push(city); }
    if (state !== undefined) { updates.push('state = ?'); params.push(state); }
    if (pincode !== undefined) { updates.push('pincode = ?'); params.push(pincode); }
    if (emergency_level !== undefined) { updates.push('emergency_level = ?'); params.push(emergency_level); }
    if (required_date !== undefined) { updates.push('required_date = ?'); params.push(required_date); }
    if (contact_number !== undefined) { updates.push('contact_number = ?'); params.push(contact_number); }
    if (additional_notes !== undefined) { updates.push('additional_notes = ?'); params.push(additional_notes); }
    if (status !== undefined && req.user.role === 'admin') {
      updates.push('status = ?');
      params.push(status);
    }

    if (updates.length === 0) {
      return sendError(res, 'No update fields provided', 'Bad request', 400);
    }

    params.push(requestId);
    await pool.query(`UPDATE blood_requests SET ${updates.join(', ')} WHERE request_id = ?`, params);

    return sendSuccess(res, 'Blood request updated successfully');
  } catch (error) {
    next(error);
  }
}

/**
 * Update request status (Admin action: Pending, Approved, Fulfilled, Rejected, Cancelled)
 */
async function updateRequestStatus(req, res, next) {
  try {
    const requestId = parseInt(req.params.id, 10);
    const { status } = req.body;

    const validStatuses = ['Pending', 'Approved', 'Fulfilled', 'Rejected', 'Cancelled'];
    if (!status || !validStatuses.includes(status)) {
      return sendError(res, 'Invalid status', `Status must be one of: ${validStatuses.join(', ')}`, 400);
    }

    const [result] = await pool.query(
      'UPDATE blood_requests SET status = ? WHERE request_id = ?',
      [status, requestId]
    );

    if (result.affectedRows === 0) {
      return sendError(res, 'Request not found', 'No request with this ID', 404);
    }

    return sendSuccess(res, `Request status changed to ${status}`);
  } catch (error) {
    next(error);
  }
}

/**
 * Delete / Cancel blood request
 */
async function deleteRequest(req, res, next) {
  try {
    const requestId = parseInt(req.params.id, 10);

    const [existing] = await pool.query(
      'SELECT requester_id FROM blood_requests WHERE request_id = ?',
      [requestId]
    );

    if (existing.length === 0) {
      return sendError(res, 'Request not found', 'No request with this ID', 404);
    }

    if (req.user.role !== 'admin' && existing[0].requester_id !== req.user.user_id) {
      return sendError(res, 'Unauthorized', 'You can only delete your own requests', 403);
    }

    await pool.query('DELETE FROM blood_requests WHERE request_id = ?', [requestId]);

    return sendSuccess(res, 'Blood request deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllRequests,
  getRequestById,
  createRequest,
  updateRequest,
  updateRequestStatus,
  deleteRequest
};
