const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');
const { JWT_SECRET } = require('../middleware/authMiddleware');

/**
 * Register new user (or donor)
 */
async function register(req, res, next) {
  const connection = await pool.getConnection();
  try {
    const {
      full_name,
      email,
      phone,
      password,
      role = 'user',
      // Optional donor fields if registering directly as donor
      blood_group,
      date_of_birth,
      age,
      gender,
      address,
      city,
      state,
      pincode,
      latitude,
      longitude
    } = req.body;

    // Check if email already registered
    const [existing] = await connection.query(
      'SELECT user_id FROM users WHERE email = ?',
      [email.toLowerCase()]
    );
    if (existing.length > 0) {
      return sendError(res, 'Email already registered', 'An account with this email already exists', 409);
    }

    await connection.beginTransaction();

    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    const targetRole = ['admin', 'donor', 'user'].includes(role) ? role : 'user';

    const [userResult] = await connection.query(
      `INSERT INTO users (full_name, email, phone, password_hash, role)
       VALUES (?, ?, ?, ?, ?)`,
      [full_name, email.toLowerCase(), phone, password_hash, targetRole]
    );

    const userId = userResult.insertId;

    // If role is donor, create linked donor profile
    let donorProfile = null;
    if (targetRole === 'donor') {
      const calculatedAge = age || (date_of_birth ? Math.floor((new Date() - new Date(date_of_birth)) / (365.25 * 24 * 60 * 60 * 1000)) : 25);
      const dob = date_of_birth || '1998-01-01';
      const bGroup = blood_group || 'O+';
      const gdr = gender || 'Male';
      const addr = address || 'Not specified';
      const cty = city || 'Hyderabad';
      const st = state || 'Telangana';
      const pin = pincode || '500001';
      const lat = latitude || null;
      const lng = longitude || null;

      const [donorResult] = await connection.query(
        `INSERT INTO donors (
          user_id, blood_group, date_of_birth, age, gender, phone, email,
          address, city, state, pincode, latitude, longitude,
          availability_status, medical_eligibility
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Available', 'Eligible')`,
        [userId, bGroup, dob, calculatedAge, gdr, phone, email.toLowerCase(), addr, cty, st, pin, lat, lng]
      );

      donorProfile = {
        donor_id: donorResult.insertId,
        blood_group: bGroup,
        availability_status: 'Available'
      };
    }

    await connection.commit();

    // Generate JWT token
    const token = jwt.sign(
      { user_id: userId, email: email.toLowerCase(), role: targetRole },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return sendSuccess(
      res,
      'User registered successfully',
      {
        token,
        user: {
          user_id: userId,
          full_name,
          email: email.toLowerCase(),
          phone,
          role: targetRole,
          donorProfile
        }
      },
      201
    );
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
}

/**
 * Login user
 */
async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    const [users] = await pool.query(
      `SELECT user_id, full_name, email, phone, password_hash, role, created_at
       FROM users WHERE email = ?`,
      [email.toLowerCase()]
    );

    if (users.length === 0) {
      return sendError(res, 'Invalid credentials', 'Invalid email or password', 401);
    }

    const user = users[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return sendError(res, 'Invalid credentials', 'Invalid email or password', 401);
    }

    // If user is a donor, also fetch donor profile details
    let donorProfile = null;
    if (user.role === 'donor') {
      const [donors] = await pool.query(
        `SELECT donor_id, blood_group, age, gender, address, city, state, pincode,
                latitude, longitude, last_donation_date, total_donations,
                availability_status, medical_eligibility
         FROM donors WHERE user_id = ?`,
        [user.user_id]
      );
      if (donors.length > 0) {
        donorProfile = donors[0];
      }
    }

    const token = jwt.sign(
      { user_id: user.user_id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password_hash, ...safeUser } = user;
    safeUser.donorProfile = donorProfile;

    return sendSuccess(res, 'Login successful', {
      token,
      user: safeUser
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Get current authenticated user session data
 */
async function getMe(req, res, next) {
  try {
    const userId = req.user.user_id;

    const [users] = await pool.query(
      `SELECT user_id, full_name, email, phone, role, created_at, updated_at
       FROM users WHERE user_id = ?`,
      [userId]
    );

    if (users.length === 0) {
      return sendError(res, 'User not found', 'No user associated with current session', 404);
    }

    const user = users[0];
    let donorProfile = null;

    if (user.role === 'donor' || user.role === 'admin') {
      const [donors] = await pool.query(
        `SELECT donor_id, blood_group, date_of_birth, age, gender, address, city, state, pincode,
                latitude, longitude, last_donation_date, total_donations,
                availability_status, medical_eligibility, created_at, updated_at
         FROM donors WHERE user_id = ?`,
        [userId]
      );
      if (donors.length > 0) {
        donorProfile = donors[0];
      }
    }

    user.donorProfile = donorProfile;
    return sendSuccess(res, 'User session retrieved', user);
  } catch (error) {
    next(error);
  }
}

module.exports = {
  register,
  login,
  getMe
};
