const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');
const { calculateHaversineDistance } = require('../utils/distance');

/**
 * Get all donors with optional filters
 */
async function getAllDonors(req, res, next) {
  try {
    const { blood_group, city, availability_status, medical_eligibility } = req.query;

    let query = `
      SELECT 
        d.donor_id,
        d.user_id,
        u.full_name,
        d.blood_group,
        d.age,
        d.gender,
        d.city,
        d.state,
        d.pincode,
        d.latitude,
        d.longitude,
        d.last_donation_date,
        d.total_donations,
        d.availability_status,
        d.medical_eligibility,
        d.created_at
      FROM donors d
      INNER JOIN users u ON d.user_id = u.user_id
      WHERE 1=1
    `;
    const params = [];

    if (blood_group) {
      query += ' AND d.blood_group = ?';
      params.push(blood_group);
    }
    if (city) {
      query += ' AND LOWER(d.city) = LOWER(?)';
      params.push(city.trim());
    }
    if (availability_status) {
      query += ' AND d.availability_status = ?';
      params.push(availability_status);
    }
    if (medical_eligibility) {
      query += ' AND d.medical_eligibility = ?';
      params.push(medical_eligibility);
    }

    query += ' ORDER BY d.availability_status ASC, d.last_donation_date ASC, d.donor_id DESC';

    const [donors] = await pool.query(query, params);

    return sendSuccess(res, 'Donors retrieved successfully', donors);
  } catch (error) {
    next(error);
  }
}

/**
 * Get donor by ID
 */
async function getDonorById(req, res, next) {
  try {
    const donorId = parseInt(req.params.id, 10);

    const [rows] = await pool.query(
      `SELECT 
        d.donor_id,
        d.user_id,
        u.full_name,
        u.email,
        u.phone,
        d.blood_group,
        d.date_of_birth,
        d.age,
        d.gender,
        d.address,
        d.city,
        d.state,
        d.pincode,
        d.latitude,
        d.longitude,
        d.last_donation_date,
        d.total_donations,
        d.availability_status,
        d.medical_eligibility,
        d.created_at,
        d.updated_at
      FROM donors d
      INNER JOIN users u ON d.user_id = u.user_id
      WHERE d.donor_id = ?`,
      [donorId]
    );

    if (rows.length === 0) {
      return sendError(res, 'Donor not found', 'No donor found with the specified ID', 404);
    }

    const donor = rows[0];

    // Fetch donation history
    const [donations] = await pool.query(
      `SELECT d.donation_id, d.donation_date, d.blood_group, d.units_donated, d.notes,
              bb.bank_name, bb.city AS bank_city
       FROM donations d
       INNER JOIN blood_banks bb ON d.blood_bank_id = bb.blood_bank_id
       WHERE d.donor_id = ?
       ORDER BY d.donation_date DESC`,
      [donorId]
    );

    donor.donations = donations;

    return sendSuccess(res, 'Donor details retrieved', donor);
  } catch (error) {
    next(error);
  }
}

/**
 * Search donors with multi-field search and distance support
 */
async function searchDonors(req, res, next) {
  try {
    const { blood_group, city, state, pincode, lat, lng, radius = 50 } = req.query;

    let query = `
      SELECT 
        d.donor_id,
        d.user_id,
        u.full_name,
        u.phone,
        u.email,
        d.blood_group,
        d.age,
        d.gender,
        d.address,
        d.city,
        d.state,
        d.pincode,
        d.latitude,
        d.longitude,
        d.last_donation_date,
        d.total_donations,
        d.availability_status,
        d.medical_eligibility
      FROM donors d
      INNER JOIN users u ON d.user_id = u.user_id
      WHERE d.medical_eligibility = 'Eligible'
    `;
    const params = [];

    if (blood_group && blood_group !== 'All') {
      query += ' AND d.blood_group = ?';
      params.push(blood_group);
    }
    if (city && city.trim() !== '') {
      query += ' AND LOWER(d.city) LIKE LOWER(?)';
      params.push(`%${city.trim()}%`);
    }
    if (state && state.trim() !== '') {
      query += ' AND LOWER(d.state) LIKE LOWER(?)';
      params.push(`%${state.trim()}%`);
    }
    if (pincode && pincode.trim() !== '') {
      query += ' AND d.pincode = ?';
      params.push(pincode.trim());
    }

    const [rows] = await pool.query(query, params);

    let results = rows;

    // If geographic coordinates are provided, compute Haversine distance
    if (lat && lng && !isNaN(lat) && !isNaN(lng)) {
      const userLat = parseFloat(lat);
      const userLng = parseFloat(lng);
      const maxRadius = parseFloat(radius) || 50;

      results = rows
        .map(donor => {
          let distance = null;
          if (donor.latitude !== null && donor.longitude !== null) {
            distance = calculateHaversineDistance(
              userLat,
              userLng,
              parseFloat(donor.latitude),
              parseFloat(donor.longitude)
            );
          }
          return {
            ...donor,
            distance_km: distance
          };
        })
        .filter(donor => donor.distance_km === null || donor.distance_km <= maxRadius)
        .sort((a, b) => {
          if (a.distance_km === null) return 1;
          if (b.distance_km === null) return -1;
          return a.distance_km - b.distance_km;
        });
    }

    return sendSuccess(res, 'Search completed successfully', results);
  } catch (error) {
    next(error);
  }
}

/**
 * Get nearby donors within radius based on Geolocation
 */
async function getNearbyDonors(req, res, next) {
  try {
    const { lat, lng, radius = 50, blood_group } = req.query;

    if (!lat || !lng || isNaN(lat) || isNaN(lng)) {
      return sendError(res, 'Valid latitude and longitude are required', 'Missing coordinates', 400);
    }

    const userLat = parseFloat(lat);
    const userLng = parseFloat(lng);
    const maxRadius = parseFloat(radius);

    let query = `
      SELECT 
        d.donor_id,
        d.user_id,
        u.full_name,
        u.phone,
        d.blood_group,
        d.age,
        d.gender,
        d.city,
        d.state,
        d.pincode,
        d.latitude,
        d.longitude,
        d.availability_status,
        d.medical_eligibility,
        d.total_donations
      FROM donors d
      INNER JOIN users u ON d.user_id = u.user_id
      WHERE d.latitude IS NOT NULL 
        AND d.longitude IS NOT NULL
        AND d.availability_status = 'Available'
        AND d.medical_eligibility = 'Eligible'
    `;
    const params = [];

    if (blood_group && blood_group !== 'All') {
      query += ' AND d.blood_group = ?';
      params.push(blood_group);
    }

    const [rows] = await pool.query(query, params);

    const nearbyDonors = rows
      .map(donor => {
        const distance = calculateHaversineDistance(
          userLat,
          userLng,
          parseFloat(donor.latitude),
          parseFloat(donor.longitude)
        );
        return {
          ...donor,
          distance_km: distance
        };
      })
      .filter(donor => donor.distance_km <= maxRadius)
      .sort((a, b) => a.distance_km - b.distance_km);

    return sendSuccess(res, 'Nearby donors found', nearbyDonors);
  } catch (error) {
    next(error);
  }
}

/**
 * Create or register donor profile
 */
async function createDonor(req, res, next) {
  try {
    const {
      blood_group,
      date_of_birth,
      age,
      gender,
      phone,
      email,
      address,
      city,
      state,
      pincode,
      latitude,
      longitude,
      availability_status = 'Available',
      medical_eligibility = 'Eligible'
    } = req.body;

    const targetUserId = req.user.role === 'admin' && req.body.user_id
      ? req.body.user_id
      : req.user.user_id;

    // Check if donor profile already exists for user
    const [existing] = await pool.query(
      'SELECT donor_id FROM donors WHERE user_id = ?',
      [targetUserId]
    );

    if (existing.length > 0) {
      return sendError(res, 'Donor profile already exists for this account', 'Duplicate donor', 409);
    }

    const calculatedAge = age || Math.floor((new Date() - new Date(date_of_birth)) / (365.25 * 24 * 60 * 60 * 1000));
    const donorEmail = email || req.user.email;
    const donorPhone = phone || req.user.phone;

    const [result] = await pool.query(
      `INSERT INTO donors (
        user_id, blood_group, date_of_birth, age, gender, phone, email,
        address, city, state, pincode, latitude, longitude,
        availability_status, medical_eligibility
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        targetUserId,
        blood_group,
        date_of_birth,
        calculatedAge,
        gender,
        donorPhone,
        donorEmail,
        address,
        city,
        state,
        pincode,
        latitude || null,
        longitude || null,
        availability_status,
        medical_eligibility
      ]
    );

    // Update user role to donor if not admin
    if (req.user.role === 'user') {
      await pool.query('UPDATE users SET role = "donor" WHERE user_id = ?', [targetUserId]);
    }

    return sendSuccess(
      res,
      'Donor profile registered successfully',
      { donor_id: result.insertId },
      201
    );
  } catch (error) {
    next(error);
  }
}

/**
 * Update donor profile / location / availability
 */
async function updateDonor(req, res, next) {
  try {
    const donorId = parseInt(req.params.id, 10);

    // Check donor exists and verify ownership
    const [existing] = await pool.query(
      'SELECT donor_id, user_id FROM donors WHERE donor_id = ?',
      [donorId]
    );

    if (existing.length === 0) {
      return sendError(res, 'Donor not found', 'No donor found with this ID', 404);
    }

    if (req.user.role !== 'admin' && existing[0].user_id !== req.user.user_id) {
      return sendError(res, 'Unauthorized', 'You can only update your own donor profile', 403);
    }

    const {
      blood_group,
      date_of_birth,
      age,
      gender,
      phone,
      address,
      city,
      state,
      pincode,
      latitude,
      longitude,
      availability_status,
      medical_eligibility,
      last_donation_date,
      total_donations
    } = req.body;

    const updates = [];
    const params = [];

    if (blood_group !== undefined) { updates.push('blood_group = ?'); params.push(blood_group); }
    if (date_of_birth !== undefined) { updates.push('date_of_birth = ?'); params.push(date_of_birth); }
    if (age !== undefined) { updates.push('age = ?'); params.push(age); }
    if (gender !== undefined) { updates.push('gender = ?'); params.push(gender); }
    if (phone !== undefined) { updates.push('phone = ?'); params.push(phone); }
    if (address !== undefined) { updates.push('address = ?'); params.push(address); }
    if (city !== undefined) { updates.push('city = ?'); params.push(city); }
    if (state !== undefined) { updates.push('state = ?'); params.push(state); }
    if (pincode !== undefined) { updates.push('pincode = ?'); params.push(pincode); }
    if (latitude !== undefined) { updates.push('latitude = ?'); params.push(latitude !== '' ? latitude : null); }
    if (longitude !== undefined) { updates.push('longitude = ?'); params.push(longitude !== '' ? longitude : null); }
    if (availability_status !== undefined) { updates.push('availability_status = ?'); params.push(availability_status); }
    if (medical_eligibility !== undefined && req.user.role === 'admin') {
      updates.push('medical_eligibility = ?'); params.push(medical_eligibility);
    }
    if (last_donation_date !== undefined) { updates.push('last_donation_date = ?'); params.push(last_donation_date); }
    if (total_donations !== undefined && req.user.role === 'admin') {
      updates.push('total_donations = ?'); params.push(total_donations);
    }

    if (updates.length === 0) {
      return sendError(res, 'No update fields provided', 'Bad request', 400);
    }

    params.push(donorId);
    await pool.query(`UPDATE donors SET ${updates.join(', ')} WHERE donor_id = ?`, params);

    return sendSuccess(res, 'Donor profile updated successfully');
  } catch (error) {
    next(error);
  }
}

/**
 * Delete or deactivate donor
 */
async function deleteDonor(req, res, next) {
  try {
    const donorId = parseInt(req.params.id, 10);

    const [existing] = await pool.query('SELECT donor_id, user_id FROM donors WHERE donor_id = ?', [donorId]);
    if (existing.length === 0) {
      return sendError(res, 'Donor not found', 'No donor found with this ID', 404);
    }

    await pool.query('DELETE FROM donors WHERE donor_id = ?', [donorId]);

    return sendSuccess(res, 'Donor record deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllDonors,
  getDonorById,
  searchDonors,
  getNearbyDonors,
  createDonor,
  updateDonor,
  deleteDonor
};
