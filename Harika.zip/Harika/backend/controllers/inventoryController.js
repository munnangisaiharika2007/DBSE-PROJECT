const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');

/**
 * Get all inventory records across all blood banks with status calculation
 */
async function getAllInventory(req, res, next) {
  try {
    const { blood_group, blood_bank_id, stock_status } = req.query;

    let query = `
      SELECT 
        bi.inventory_id,
        bi.blood_bank_id,
        bb.bank_name,
        bb.city,
        bb.contact_number,
        bi.blood_group,
        bi.units_available,
        bi.minimum_required_units,
        bi.last_updated,
        CASE
          WHEN bi.units_available = 0 THEN 'Out of Stock'
          WHEN bi.units_available < (bi.minimum_required_units / 2) THEN 'Critical'
          WHEN bi.units_available < bi.minimum_required_units THEN 'Low Stock'
          ELSE 'Available'
        END AS stock_status
      FROM blood_inventory bi
      INNER JOIN blood_banks bb ON bi.blood_bank_id = bb.blood_bank_id
      WHERE 1=1
    `;
    const params = [];

    if (blood_group && blood_group !== 'All') {
      query += ' AND bi.blood_group = ?';
      params.push(blood_group);
    }
    if (blood_bank_id) {
      query += ' AND bi.blood_bank_id = ?';
      params.push(blood_bank_id);
    }

    query += ' ORDER BY bb.bank_name ASC, bi.blood_group ASC';

    const [rows] = await pool.query(query, params);

    let filtered = rows;
    if (stock_status && stock_status !== 'All') {
      filtered = rows.filter(item => item.stock_status.toLowerCase() === stock_status.toLowerCase());
    }

    return sendSuccess(res, 'Inventory retrieved successfully', filtered);
  } catch (error) {
    next(error);
  }
}

/**
 * Get inventory for a specific blood bank
 */
async function getInventoryByBloodBank(req, res, next) {
  try {
    const bloodBankId = parseInt(req.params.bloodBankId, 10);

    const [inventory] = await pool.query(
      `SELECT 
        bi.inventory_id,
        bi.blood_bank_id,
        bb.bank_name,
        bi.blood_group,
        bi.units_available,
        bi.minimum_required_units,
        bi.last_updated,
        CASE
          WHEN bi.units_available = 0 THEN 'Out of Stock'
          WHEN bi.units_available < (bi.minimum_required_units / 2) THEN 'Critical'
          WHEN bi.units_available < bi.minimum_required_units THEN 'Low Stock'
          ELSE 'Available'
        END AS stock_status
      FROM blood_inventory bi
      INNER JOIN blood_banks bb ON bi.blood_bank_id = bb.blood_bank_id
      WHERE bi.blood_bank_id = ?
      ORDER BY bi.blood_group ASC`,
      [bloodBankId]
    );

    return sendSuccess(res, 'Blood bank inventory retrieved', inventory);
  } catch (error) {
    next(error);
  }
}

/**
 * Create or Update inventory item
 */
async function createOrUpdateInventory(req, res, next) {
  try {
    const { blood_bank_id, blood_group, units_available, minimum_required_units = 10 } = req.body;

    if (!blood_bank_id || !blood_group || units_available === undefined) {
      return sendError(res, 'Missing required fields', 'blood_bank_id, blood_group, units_available required', 400);
    }

    const [result] = await pool.query(
      `INSERT INTO blood_inventory (blood_bank_id, blood_group, units_available, minimum_required_units)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE 
         units_available = VALUES(units_available),
         minimum_required_units = VALUES(minimum_required_units),
         last_updated = CURRENT_TIMESTAMP`,
      [blood_bank_id, blood_group, units_available, minimum_required_units]
    );

    return sendSuccess(res, 'Inventory updated successfully', { inventory_id: result.insertId });
  } catch (error) {
    next(error);
  }
}

/**
 * Update inventory by ID
 */
async function updateInventory(req, res, next) {
  try {
    const inventoryId = parseInt(req.params.id, 10);
    const { units_available, minimum_required_units } = req.body;

    const updates = [];
    const params = [];

    if (units_available !== undefined) {
      updates.push('units_available = ?');
      params.push(units_available);
    }
    if (minimum_required_units !== undefined) {
      updates.push('minimum_required_units = ?');
      params.push(minimum_required_units);
    }

    if (updates.length === 0) {
      return sendError(res, 'No update fields provided', 'Bad request', 400);
    }

    params.push(inventoryId);
    const [result] = await pool.query(
      `UPDATE blood_inventory SET ${updates.join(', ')}, last_updated = CURRENT_TIMESTAMP WHERE inventory_id = ?`,
      params
    );

    if (result.affectedRows === 0) {
      return sendError(res, 'Inventory item not found', 'No item with this ID', 404);
    }

    return sendSuccess(res, 'Inventory item updated successfully');
  } catch (error) {
    next(error);
  }
}

/**
 * Delete inventory by ID
 */
async function deleteInventory(req, res, next) {
  try {
    const inventoryId = parseInt(req.params.id, 10);

    const [result] = await pool.query('DELETE FROM blood_inventory WHERE inventory_id = ?', [inventoryId]);
    if (result.affectedRows === 0) {
      return sendError(res, 'Inventory item not found', 'No item with this ID', 404);
    }

    return sendSuccess(res, 'Inventory record deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllInventory,
  getInventoryByBloodBank,
  createOrUpdateInventory,
  updateInventory,
  deleteInventory
};
