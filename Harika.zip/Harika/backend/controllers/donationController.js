const { pool } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHandler');

/**
 * Get all donations (with donor and blood bank details)
 */
async function getAllDonations(req, res, next) {
  try {
    const { blood_group, blood_bank_id } = req.query;

    let query = `
      SELECT 
        d.donation_id,
        d.donor_id,
        u.full_name AS donor_name,
        d.blood_group,
        d.donation_date,
        d.units_donated,
        d.notes,
        d.created_at,
        bb.blood_bank_id,
        bb.bank_name,
        bb.city AS blood_bank_city
      FROM donations d
      INNER JOIN donors dn ON d.donor_id = dn.donor_id
      INNER JOIN users u ON dn.user_id = u.user_id
      INNER JOIN blood_banks bb ON d.blood_bank_id = bb.blood_bank_id
      WHERE 1=1
    `;
    const params = [];

    if (blood_group && blood_group !== 'All') {
      query += ' AND d.blood_group = ?';
      params.push(blood_group);
    }
    if (blood_bank_id) {
      query += ' AND d.blood_bank_id = ?';
      params.push(blood_bank_id);
    }

    query += ' ORDER BY d.donation_date DESC, d.donation_id DESC';

    const [rows] = await pool.query(query, params);

    return sendSuccess(res, 'Donation records retrieved', rows);
  } catch (error) {
    next(error);
  }
}

/**
 * Get donations by specific donor ID
 */
async function getDonationsByDonorId(req, res, next) {
  try {
    const donorId = parseInt(req.params.donorId, 10);

    const [rows] = await pool.query(
      `SELECT 
        d.donation_id,
        d.donor_id,
        d.blood_group,
        d.donation_date,
        d.units_donated,
        d.notes,
        d.created_at,
        bb.blood_bank_id,
        bb.bank_name,
        bb.city AS blood_bank_city
      FROM donations d
      INNER JOIN blood_banks bb ON d.blood_bank_id = bb.blood_bank_id
      WHERE d.donor_id = ?
      ORDER BY d.donation_date DESC`,
      [donorId]
    );

    return sendSuccess(res, 'Donor donation history retrieved', rows);
  } catch (error) {
    next(error);
  }
}

/**
 * Record a new donation (updates donor stats & increments blood bank inventory)
 */
async function createDonation(req, res, next) {
  const connection = await pool.getConnection();
  try {
    const {
      donor_id,
      blood_bank_id,
      donation_date = new Date().toISOString().split('T')[0],
      blood_group,
      units_donated = 1,
      notes
    } = req.body;

    if (!donor_id || !blood_bank_id || !blood_group) {
      return sendError(res, 'Missing required donation fields', 'donor_id, blood_bank_id, blood_group required', 400);
    }

    await connection.beginTransaction();

    // 1. Insert donation record
    const [result] = await connection.query(
      `INSERT INTO donations (donor_id, blood_bank_id, donation_date, blood_group, units_donated, notes)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [donor_id, blood_bank_id, donation_date, blood_group, units_donated, notes || null]
    );

    // 2. Update donor total_donations count and last_donation_date
    await connection.query(
      `UPDATE donors 
       SET total_donations = total_donations + ?,
           last_donation_date = ?
       WHERE donor_id = ?`,
      [units_donated, donation_date, donor_id]
    );

    // 3. Atomically increment blood bank inventory units
    await connection.query(
      `INSERT INTO blood_inventory (blood_bank_id, blood_group, units_available, minimum_required_units)
       VALUES (?, ?, ?, 10)
       ON DUPLICATE KEY UPDATE 
         units_available = units_available + VALUES(units_available),
         last_updated = CURRENT_TIMESTAMP`,
      [blood_bank_id, blood_group, units_donated]
    );

    await connection.commit();

    return sendSuccess(
      res,
      'Donation recorded and inventory successfully updated',
      { donation_id: result.insertId },
      201
    );
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
}

module.exports = {
  getAllDonations,
  getDonationsByDonorId,
  createDonation
};
