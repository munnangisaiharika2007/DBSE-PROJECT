/**
 * Blood Bank Management & Directory Controller
 * Blood Bank and Donor Location System
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('blood-banks-grid')) {
    initBloodBanksDirectoryPage();
  }
  if (document.getElementById('admin-banks-table-body')) {
    initAdminBloodBanksPage();
  }
});

let cachedBloodBanks = [];

/**
 * -----------------------------------------------------------------------------
 * PUBLIC BLOOD BANKS DIRECTORY (blood-banks.html)
 * -----------------------------------------------------------------------------
 */
async function initBloodBanksDirectoryPage() {
  const container = document.getElementById('blood-banks-grid');
  showLoading('blood-banks-grid');

  try {
    const res = await apiGet('/blood-banks');
    cachedBloodBanks = res.data;
    renderBloodBanksGrid(cachedBloodBanks);

    const searchInput = document.getElementById('search-bank-query');
    const cityFilter = document.getElementById('filter-bank-city');

    const handleFilter = () => {
      const q = searchInput ? searchInput.value.toLowerCase().trim() : '';
      const c = cityFilter ? cityFilter.value.toLowerCase().trim() : '';

      const filtered = cachedBloodBanks.filter(bank => {
        const matchQ = !q || bank.bank_name.toLowerCase().includes(q) || bank.address.toLowerCase().includes(q);
        const matchC = !c || bank.city.toLowerCase().includes(c);
        return matchQ && matchC;
      });

      renderBloodBanksGrid(filtered);
    };

    if (searchInput) searchInput.addEventListener('input', handleFilter);
    if (cityFilter) cityFilter.addEventListener('change', handleFilter);

  } catch (error) {
    showToast('Failed to load blood banks: ' + error.message, 'error');
  }
}

function renderBloodBanksGrid(banks) {
  const container = document.getElementById('blood-banks-grid');
  const countEl = document.getElementById('banks-count');
  if (countEl) countEl.textContent = banks.length;

  if (banks.length === 0) {
    showEmptyState('blood-banks-grid', 'No blood banks match your search criteria.');
    return;
  }

  container.innerHTML = `
    <div class="row g-4">
      ${banks.map(bank => `
        <div class="col-md-6 col-lg-4">
          <div class="card card-custom h-100">
            <div class="card-body-custom d-flex flex-column">
              <div class="d-flex align-items-start justify-content-between mb-3">
                <div class="stat-icon-wrapper stat-icon-blue">
                  <i class="bi bi-hospital fs-4"></i>
                </div>
                ${bank.emergency_available ? `
                  <span class="badge bg-danger rounded-pill px-3 py-1">
                    <i class="bi bi-lightning-fill me-1"></i> 24/7 Emergency
                  </span>
                ` : `
                  <span class="badge bg-secondary rounded-pill px-3 py-1">Standard Hours</span>
                `}
              </div>

              <h5 class="fw-bold mb-1 text-secondary">${bank.bank_name}</h5>
              <p class="text-muted small mb-2"><i class="bi bi-geo-alt me-1 text-danger"></i>${bank.address}, ${bank.city} (${bank.pincode})</p>

              <div class="bg-light p-3 rounded-3 small mb-3 mt-auto">
                <div class="d-flex justify-content-between py-1 border-bottom">
                  <span class="text-muted">License No:</span>
                  <span class="fw-semibold">${bank.license_number}</span>
                </div>
                <div class="d-flex justify-content-between py-1 border-bottom">
                  <span class="text-muted">Operating Hours:</span>
                  <span class="fw-semibold">${bank.opening_time.slice(0, 5)} - ${bank.closing_time.slice(0, 5)}</span>
                </div>
                <div class="d-flex justify-content-between py-1">
                  <span class="text-muted">Total Stock Available:</span>
                  <span class="badge bg-success">${bank.total_units_available || 0} Units</span>
                </div>
              </div>

              <div class="d-flex gap-2">
                <button class="btn btn-outline-primary btn-sm flex-grow-1 rounded-pill" onclick="viewBloodBankDetails(${bank.blood_bank_id})">
                  <i class="bi bi-droplet-half me-1"></i> View Stock
                </button>
                <a href="tel:${bank.contact_number}" class="btn btn-brand-primary btn-sm rounded-pill px-3">
                  <i class="bi bi-telephone-fill"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

/**
 * View Blood Bank Stock Modal
 */
async function viewBloodBankDetails(bankId) {
  try {
    const res = await apiGet(`/blood-banks/${bankId}`);
    const bank = res.data;

    let modalEl = document.getElementById('bankDetailsModal');
    if (!modalEl) {
      modalEl = document.createElement('div');
      modalEl.className = 'modal fade';
      modalEl.id = 'bankDetailsModal';
      modalEl.tabIndex = -1;
      document.body.appendChild(modalEl);
    }

    const inventoryHtml = bank.inventory && bank.inventory.length > 0 ? `
      <div class="row g-2 mt-2">
        ${bank.inventory.map(inv => {
          let badgeClass = 'bg-success';
          if (inv.stock_status === 'Critical') badgeClass = 'bg-danger';
          else if (inv.stock_status === 'Low Stock') badgeClass = 'bg-warning text-dark';
          else if (inv.stock_status === 'Out of Stock') badgeClass = 'bg-secondary';

          return `
            <div class="col-3">
              <div class="border rounded p-2 text-center bg-light">
                <span class="fw-bold text-danger fs-6">${inv.blood_group}</span>
                <div class="fw-bold fs-5">${inv.units_available}</div>
                <span class="badge ${badgeClass}" style="font-size: 0.65rem;">${inv.stock_status}</span>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    ` : '<p class="text-muted small">No inventory reported yet.</p>';

    modalEl.innerHTML = `
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg" style="border-radius: var(--radius-lg);">
          <div class="modal-header bg-primary text-white">
            <h5 class="modal-title fw-bold"><i class="bi bi-hospital me-2"></i>${bank.bank_name}</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-4">
            <div class="row g-3 mb-4">
              <div class="col-md-6">
                <h6 class="text-muted small text-uppercase fw-bold mb-2">Hospital / Bank Details</h6>
                <p class="mb-1"><strong>Address:</strong> ${bank.address}, ${bank.city}, ${bank.state} - ${bank.pincode}</p>
                <p class="mb-1"><strong>License:</strong> ${bank.license_number}</p>
                <p class="mb-1"><strong>Hours:</strong> ${bank.opening_time.slice(0, 5)} - ${bank.closing_time.slice(0, 5)}</p>
                <p class="mb-1"><strong>Emergency Availability:</strong> ${bank.emergency_available ? '<span class="text-success fw-bold">Available 24/7</span>' : 'Standard'}</p>
              </div>
              <div class="col-md-6">
                <h6 class="text-muted small text-uppercase fw-bold mb-2">Contact Channels</h6>
                <p class="mb-1"><strong>Phone:</strong> <a href="tel:${bank.contact_number}">${bank.contact_number}</a></p>
                <p class="mb-1"><strong>Email:</strong> <a href="mailto:${bank.email}">${bank.email}</a></p>
                <p class="mb-1"><strong>GPS Coordinates:</strong> ${parseFloat(bank.latitude).toFixed(4)}, ${parseFloat(bank.longitude).toFixed(4)}</p>
              </div>
            </div>

            <h6 class="text-secondary fw-bold mb-2 border-top pt-3"><i class="bi bi-droplet-half text-danger me-2"></i>Current Blood Stock Levels</h6>
            ${inventoryHtml}

            <div class="mt-4 pt-3 border-top d-flex justify-content-end gap-2">
              <a href="tel:${bank.contact_number}" class="btn btn-primary rounded-pill px-4">
                <i class="bi bi-telephone-fill me-2"></i> Call Blood Bank
              </a>
              <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const bsModal = new bootstrap.Modal(modalEl);
    bsModal.show();
  } catch (error) {
    showToast('Failed to load blood bank details: ' + error.message, 'error');
  }
}

/**
 * -----------------------------------------------------------------------------
 * ADMIN BLOOD BANK MANAGEMENT (manage-blood-banks.html)
 * -----------------------------------------------------------------------------
 */
async function initAdminBloodBanksPage() {
  if (!requireAuth(['admin'])) return;
  loadAdminBloodBanksTable();
  setupAddBloodBankForm();
}

async function loadAdminBloodBanksTable() {
  const tbody = document.getElementById('admin-banks-table-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-danger spinner-border-sm me-2"></div>Loading blood banks...</td></tr>';

  try {
    const res = await apiGet('/blood-banks');
    const banks = res.data;

    if (banks.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No blood banks registered yet.</td></tr>';
      return;
    }

    tbody.innerHTML = banks.map(b => `
      <tr>
        <td class="fw-semibold">#${b.blood_bank_id}</td>
        <td>
          <div class="fw-bold">${b.bank_name}</div>
          <small class="text-muted">${b.city}, ${b.pincode}</small>
        </td>
        <td><code>${b.license_number}</code></td>
        <td>${b.contact_number}</td>
        <td><span class="badge bg-success">${b.total_units_available || 0} Units</span></td>
        <td>
          <span class="badge ${b.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${b.status}</span>
        </td>
        <td>
          <div class="d-flex gap-1">
            <button class="btn btn-sm btn-outline-primary" onclick="viewBloodBankDetails(${b.blood_bank_id})" title="View Stock">
              <i class="bi bi-eye"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteBloodBankAdmin(${b.blood_bank_id}, '${b.bank_name}')" title="Delete">
              <i class="bi bi-trash"></i>
            </button>
          </div>
        </td>
      </tr>
    `).join('');
  } catch (error) {
    showToast('Failed to load blood banks: ' + error.message, 'error');
  }
}

function setupAddBloodBankForm() {
  const form = document.getElementById('add-blood-bank-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      bank_name: document.getElementById('bank-name').value.trim(),
      license_number: document.getElementById('bank-license').value.trim(),
      contact_number: document.getElementById('bank-contact').value.trim(),
      email: document.getElementById('bank-email').value.trim(),
      address: document.getElementById('bank-address').value.trim(),
      city: document.getElementById('bank-city').value.trim(),
      state: document.getElementById('bank-state').value.trim(),
      pincode: document.getElementById('bank-pincode').value.trim(),
      latitude: parseFloat(document.getElementById('bank-lat').value),
      longitude: parseFloat(document.getElementById('bank-lng').value),
      opening_time: document.getElementById('bank-open-time').value,
      closing_time: document.getElementById('bank-close-time').value,
      emergency_available: document.getElementById('bank-emergency').checked,
      status: 'Active'
    };

    try {
      await apiPost('/blood-banks', payload);
      showToast('New blood bank added successfully!', 'success');
      form.reset();
      const modalEl = document.getElementById('addBloodBankModal');
      if (modalEl) {
        const bsModal = bootstrap.Modal.getInstance(modalEl);
        if (bsModal) bsModal.hide();
      }
      loadAdminBloodBanksTable();
    } catch (error) {
      showToast('Failed to add blood bank: ' + error.message, 'error');
    }
  });
}

async function deleteBloodBankAdmin(bankId, name) {
  if (!confirm(`Are you sure you want to delete "${name}"? All associated inventory will also be removed.`)) {
    return;
  }
  try {
    await apiDelete(`/blood-banks/${bankId}`);
    showToast(`Blood bank "${name}" deleted successfully`, 'success');
    loadAdminBloodBanksTable();
  } catch (error) {
    showToast('Failed to delete blood bank: ' + error.message, 'error');
  }
}
