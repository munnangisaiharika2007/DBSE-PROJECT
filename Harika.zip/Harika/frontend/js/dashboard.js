/**
 * Dashboards and Analytics Controller
 * BloodLink – Connecting Donors, Blood Banks & Lives
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('admin-total-users')) {
    initAdminDashboard();
  }
  if (document.getElementById('donor-stat-lifetime')) {
    initDonorDashboard();
  }
});

let bloodGroupChart = null;
let inventoryChart = null;
let donationsChart = null;
let requestsChart = null;

/**
 * -----------------------------------------------------------------------------
 * ADMIN DASHBOARD (admin-dashboard.html)
 * -----------------------------------------------------------------------------
 */
async function initAdminDashboard() {
  if (!requireAuth(['admin'])) return;

  try {
    const res = await apiGet('/dashboard/stats');
    const {
      summary,
      bloodGroupDistribution,
      inventoryByGroup,
      monthlyDonations,
      requestsByStatus,
      recentRequests,
      recentDonations
    } = res.data;

    // 1. Populate Metric Cards
    document.getElementById('admin-total-users').textContent = summary.total_users || 0;
    document.getElementById('admin-total-donors').textContent = summary.total_donors || 0;
    document.getElementById('admin-available-donors').textContent = summary.available_donors || 0;
    document.getElementById('admin-total-banks').textContent = summary.total_blood_banks || 0;
    document.getElementById('admin-total-units').textContent = summary.total_blood_units || 0;
    document.getElementById('admin-pending-requests').textContent = summary.pending_requests || 0;
    document.getElementById('admin-critical-requests').textContent = summary.critical_requests || 0;
    document.getElementById('admin-total-donations').textContent = summary.total_donations || 0;

    // 2. Render Charts
    renderBloodGroupChart(bloodGroupDistribution);
    renderInventoryChart(inventoryByGroup);
    renderDonationsChart(monthlyDonations);
    renderRequestsChart(requestsByStatus);

    // 3. Render Quick Tables
    renderRecentRequestsTable(recentRequests);
    renderRecentDonationsTable(recentDonations);

  } catch (error) {
    showToast('Failed to load dashboard statistics: ' + error.message, 'error');
  }
}

function getChartTextColor() {
  return document.documentElement.getAttribute('data-theme') === 'dark' ? '#94a3b8' : '#64748b';
}

function getChartGridColor() {
  return document.documentElement.getAttribute('data-theme') === 'dark' ? '#1e293b' : '#f1f5f9';
}

function renderBloodGroupChart(data) {
  const ctx = document.getElementById('chart-blood-groups');
  if (!ctx) return;

  const labels = data.map(d => d.blood_group);
  const values = data.map(d => d.donor_count);

  if (bloodGroupChart) bloodGroupChart.destroy();

  bloodGroupChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: [
          '#f43f5e', '#fb7185', '#e11d48', '#fda4af',
          '#0284c7', '#38bdf8', '#10b981', '#6ee7b7'
        ],
        borderWidth: 2,
        borderColor: document.documentElement.getAttribute('data-theme') === 'dark' ? '#111827' : '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: getChartTextColor(), font: { family: 'Plus Jakarta Sans', size: 11 } }
        }
      }
    }
  });
}

function renderInventoryChart(data) {
  const ctx = document.getElementById('chart-inventory-levels');
  if (!ctx) return;

  const labels = data.map(d => d.blood_group);
  const inStock = data.map(d => d.total_units);
  const required = data.map(d => d.total_required);

  if (inventoryChart) inventoryChart.destroy();

  inventoryChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'Units Available',
          data: inStock,
          backgroundColor: '#e11d48',
          borderRadius: 6
        },
        {
          label: 'Minimum Required Buffer',
          data: required,
          backgroundColor: document.documentElement.getAttribute('data-theme') === 'dark' ? '#334155' : '#e2e8f0',
          borderRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: getChartGridColor() },
          ticks: { color: getChartTextColor() }
        },
        x: {
          grid: { display: false },
          ticks: { color: getChartTextColor() }
        }
      },
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: getChartTextColor(), font: { family: 'Plus Jakarta Sans', size: 11 } }
        }
      }
    }
  });
}

function renderDonationsChart(data) {
  const ctx = document.getElementById('chart-monthly-donations');
  if (!ctx) return;

  const labels = data.length > 0 ? data.map(d => d.month_label) : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const values = data.length > 0 ? data.map(d => d.units_donated) : [3, 5, 8, 4, 7, 10];

  if (donationsChart) donationsChart.destroy();

  donationsChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Units Donated',
        data: values,
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.15)',
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#10b981',
        pointRadius: 5
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: getChartGridColor() },
          ticks: { color: getChartTextColor() }
        },
        x: {
          grid: { display: false },
          ticks: { color: getChartTextColor() }
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

function renderRequestsChart(data) {
  const ctx = document.getElementById('chart-requests-status');
  if (!ctx) return;

  const labels = data.map(d => d.status);
  const values = data.map(d => d.count);

  if (requestsChart) requestsChart.destroy();

  requestsChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#94a3b8'],
        borderWidth: 2,
        borderColor: document.documentElement.getAttribute('data-theme') === 'dark' ? '#111827' : '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: getChartTextColor(), font: { family: 'Plus Jakarta Sans', size: 11 } }
        }
      }
    }
  });
}

function renderRecentRequestsTable(requests) {
  const tbody = document.getElementById('table-recent-requests');
  if (!tbody) return;

  if (!requests || requests.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center py-3 text-muted">No recent requests</td></tr>';
    return;
  }

  tbody.innerHTML = requests.map(r => `
    <tr>
      <td class="fw-bold">${r.patient_name}</td>
      <td><span class="badge bg-danger fs-6 px-2 py-1 rounded-pill">${r.blood_group}</span></td>
      <td>${r.units_required} Units</td>
      <td>
        <span class="badge ${r.emergency_level === 'Critical' ? 'bg-danger' : r.emergency_level === 'Urgent' ? 'bg-warning text-dark' : 'bg-info text-white'} rounded-pill px-2 py-1">
          ${r.emergency_level}
        </span>
      </td>
      <td><span class="badge ${getStatusBadgeClass(r.status)} rounded-pill px-2 py-1">${r.status}</span></td>
    </tr>
  `).join('');
}

function renderRecentDonationsTable(donations) {
  const tbody = document.getElementById('table-recent-donations');
  if (!tbody) return;

  if (!donations || donations.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center py-3 text-muted">No recent donations</td></tr>';
    return;
  }

  tbody.innerHTML = donations.map(d => `
    <tr>
      <td class="fw-bold">${d.donor_name}</td>
      <td><span class="badge bg-danger fs-6 px-2 py-1 rounded-pill">${d.blood_group}</span></td>
      <td>${d.bank_name}</td>
      <td><span class="badge bg-success rounded-pill">${d.units_donated} Unit</span></td>
      <td class="text-muted small">${formatDate(d.donation_date)}</td>
    </tr>
  `).join('');
}

/**
 * -----------------------------------------------------------------------------
 * DONOR DASHBOARD (donor-dashboard.html)
 * -----------------------------------------------------------------------------
 */
async function initDonorDashboard() {
  if (!requireAuth(['donor', 'admin'])) return;

  try {
    const res = await apiGet('/auth/me');
    const user = res.data;
    const donor = user.donorProfile;

    if (donor) {
      document.getElementById('donor-name-welcome').textContent = user.full_name;
      document.getElementById('donor-group-badge').textContent = donor.blood_group;
      document.getElementById('donor-stat-lifetime').textContent = donor.total_donations || 0;
      document.getElementById('donor-stat-last-date').textContent = formatDate(donor.last_donation_date);
      document.getElementById('donor-stat-eligibility').textContent = donor.medical_eligibility || 'Eligible';

      const availBadge = document.getElementById('donor-stat-availability');
      if (availBadge) {
        availBadge.textContent = donor.availability_status;
        availBadge.className = `badge ${donor.availability_status === 'Available' ? 'bg-success text-white' : 'bg-secondary text-white'} rounded-pill px-3 py-2 fs-6`;
      }

      // Quick toggle availability button
      const toggleBtn = document.getElementById('btn-toggle-availability');
      if (toggleBtn) {
        toggleBtn.addEventListener('click', async () => {
          const nextStatus = donor.availability_status === 'Available' ? 'Temporarily Unavailable' : 'Available';
          try {
            await apiPut(`/donors/${donor.donor_id}`, { availability_status: nextStatus });
            donor.availability_status = nextStatus;
            availBadge.textContent = nextStatus;
            availBadge.className = `badge ${nextStatus === 'Available' ? 'bg-success text-white' : 'bg-secondary text-white'} rounded-pill px-3 py-2 fs-6`;
            showToast(`Status updated to ${nextStatus}`, 'success');
          } catch (err) {
            showToast('Failed to update status: ' + err.message, 'error');
          }
        });
      }

      // Load donor's donation records
      const donRes = await apiGet(`/donations/donor/${donor.donor_id}`);
      const donTable = document.getElementById('donor-donations-tbody');
      if (donTable) {
        if (donRes.data.length === 0) {
          donTable.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-muted">No past donations recorded yet.</td></tr>';
        } else {
          donTable.innerHTML = donRes.data.map(d => `
            <tr>
              <td>${formatDate(d.donation_date)}</td>
              <td>${d.bank_name} (${d.blood_bank_city})</td>
              <td><span class="badge bg-danger fs-6 px-2 py-1 rounded-pill">${d.blood_group}</span></td>
              <td><span class="badge bg-success rounded-pill px-2 py-1">${d.units_donated} Unit</span></td>
            </tr>
          `).join('');
        }
      }
    }
  } catch (error) {
    showToast('Failed to load donor data: ' + error.message, 'error');
  }
}
