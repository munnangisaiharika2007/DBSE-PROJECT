/**
 * Blood Request Management Controller
 * Blood Bank and Donor Location System
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('blood-request-form')) {
    initBloodRequestForm();
  }
  if (document.getElementById('user-requests-table-body')) {
    initUserRequestsPage();
  }
  if (document.getElementById('admin-requests-table-body')) {
    initAdminRequestsPage();
  }
});

/**
 * -----------------------------------------------------------------------------
 * BLOOD REQUEST FORM (blood-request.html)
 * -----------------------------------------------------------------------------
 */
function initBloodRequestForm() {
  if (!requireAuth()) return;

  const form = document.getElementById('blood-request-form');
  const user = getCurrentUser();

  // Prefill phone and date if available
  if (user && document.getElementById('req-contact')) {
    document.getElementById('req-contact').value = user.phone || '';
  }
  if (document.getElementById('req-date')) {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('req-date').min = today;
    document.getElementById('req-date').value = today;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Submitting Request...';

    const payload = {
      patient_name: document.getElementById('req-patient-name').value.trim(),
      blood_group: document.getElementById('req-blood-group').value,
      units_required: parseInt(document.getElementById('req-units').value, 10),
      hospital_name: document.getElementById('req-hospital-name').value.trim(),
      hospital_address: document.getElementById('req-hospital-address').value.trim(),
      city: document.getElementById('req-city').value.trim(),
      state: document.getElementById('req-state').value.trim(),
      pincode: document.getElementById('req-pincode').value.trim(),
      emergency_level: document.getElementById('req-emergency').value,
      required_date: document.getElementById('req-date').value,
      contact_number: document.getElementById('req-contact').value.trim(),
      additional_notes: document.getElementById('req-notes')?.value.trim() || ''
    };

    try {
      const res = await apiPost('/requests', payload);
      showToast('Blood request submitted successfully!', 'success');
      form.reset();
      setTimeout(() => {
        window.location.href = 'request-history.html';
      }, 1200);
    } catch (error) {
      showToast('Failed to submit request: ' + error.message, 'error');
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });
}

/**
 * -----------------------------------------------------------------------------
 * USER REQUEST HISTORY (request-history.html)
 * -----------------------------------------------------------------------------
 */
async function initUserRequestsPage() {
  if (!requireAuth()) return;
  loadUserRequests();
}

async function loadUserRequests() {
  const tbody = document.getElementById('user-requests-table-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-danger spinner-border-sm me-2"></div>Loading your requests...</td></tr>';

  try {
    const res = await apiGet('/requests', { user_only: 'true' });
    const requests = res.data;

    if (requests.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center py-5 text-muted">You have not submitted any blood requests yet. <a href="blood-request.html" class="btn btn-sm btn-outline-danger ms-2">Request Blood Now</a></td></tr>';
      return;
    }

    tbody.innerHTML = requests.map(r => `
      <tr>
        <td class="fw-semibold">#${r.request_id}</td>
        <td class="fw-bold">${r.patient_name}</td>
        <td><span class="badge bg-danger fs-6">${r.blood_group}</span></td>
        <td>${r.units_required} Units</td>
        <td>
          <div>${r.hospital_name}</div>
          <small class="text-muted">${r.city}</small>
        </td>
        <td>
          <span class="badge ${r.emergency_level === 'Critical' ? 'bg-danger' : r.emergency_level === 'Urgent' ? 'bg-warning text-dark' : 'bg-info'}">
            ${r.emergency_level}
          </span>
        </td>
        <td>
          <span class="badge ${getStatusBadgeClass(r.status)}">
            ${r.status}
          </span>
        </td>
        <td>
          ${r.status === 'Pending' ? `
            <button class="btn btn-sm btn-outline-secondary" onclick="cancelBloodRequest(${r.request_id})">
              Cancel
            </button>
          ` : '<span class="text-muted small">Locked</span>'}
        </td>
      </tr>
    `).join('');
  } catch (error) {
    showToast('Failed to load requests: ' + error.message, 'error');
  }
}

async function cancelBloodRequest(requestId) {
  if (!confirm('Are you sure you want to cancel this request?')) return;
  try {
    await apiDelete(`/requests/${requestId}`);
    showToast('Request cancelled successfully', 'info');
    loadUserRequests();
  } catch (error) {
    showToast('Failed to cancel request: ' + error.message, 'error');
  }
}

/**
 * -----------------------------------------------------------------------------
 * ADMIN REQUESTS MANAGEMENT (manage-requests.html)
 * -----------------------------------------------------------------------------
 */
async function initAdminRequestsPage() {
  if (!requireAuth(['admin'])) return;
  loadAdminRequestsTable();

  const statusFilter = document.getElementById('filter-req-status');
  const emergFilter = document.getElementById('filter-req-emergency');

  const handleFilter = () => {
    loadAdminRequestsTable({
      status: statusFilter ? statusFilter.value : 'All',
      emergency_level: emergFilter ? emergFilter.value : 'All'
    });
  };

  if (statusFilter) statusFilter.addEventListener('change', handleFilter);
  if (emergFilter) emergFilter.addEventListener('change', handleFilter);
}

async function loadAdminRequestsTable(filters = {}) {
  const tbody = document.getElementById('admin-requests-table-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4"><div class="spinner-border text-danger spinner-border-sm me-2"></div>Loading all blood requests...</td></tr>';

  try {
    const res = await apiGet('/requests', filters);
    const requests = res.data;

    if (requests.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted">No requests found.</td></tr>';
      return;
    }

    tbody.innerHTML = requests.map(r => `
      <tr>
        <td class="fw-semibold">#${r.request_id}</td>
        <td>
          <div class="fw-bold">${r.patient_name}</div>
          <small class="text-muted">By: ${r.requester_name} (${r.contact_number})</small>
        </td>
        <td><span class="badge bg-danger fs-6">${r.blood_group}</span></td>
        <td><strong>${r.units_required}</strong> Units</td>
        <td>
          <div>${r.hospital_name}</div>
          <small class="text-muted">${r.city}, ${r.pincode}</small>
        </td>
        <td>
          <span class="badge ${r.emergency_level === 'Critical' ? 'bg-danger' : r.emergency_level === 'Urgent' ? 'bg-warning text-dark' : 'bg-info'}">
            ${r.emergency_level}
          </span>
        </td>
        <td>${formatDate(r.required_date)}</td>
        <td>
          <span class="badge ${getStatusBadgeClass(r.status)}">
            ${r.status}
          </span>
        </td>
        <td>
          <div class="dropdown">
            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
              Update Status
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
              <li><button class="dropdown-item text-primary" onclick="changeRequestStatusAdmin(${r.request_id}, 'Approved')"><i class="bi bi-check2-circle me-2"></i>Approve</button></li>
              <li><button class="dropdown-item text-success" onclick="changeRequestStatusAdmin(${r.request_id}, 'Fulfilled')"><i class="bi bi-check-all me-2"></i>Mark Fulfilled</button></li>
              <li><button class="dropdown-item text-danger" onclick="changeRequestStatusAdmin(${r.request_id}, 'Rejected')"><i class="bi bi-x-circle me-2"></i>Reject</button></li>
              <li><hr class="dropdown-divider"></li>
              <li><button class="dropdown-item text-secondary" onclick="changeRequestStatusAdmin(${r.request_id}, 'Cancelled')"><i class="bi bi-slash-circle me-2"></i>Cancel</button></li>
            </ul>
          </div>
        </td>
      </tr>
    `).join('');
  } catch (error) {
    showToast('Failed to load requests: ' + error.message, 'error');
  }
}

async function changeRequestStatusAdmin(requestId, newStatus) {
  try {
    await apiPut(`/requests/${requestId}/status`, { status: newStatus });
    showToast(`Request #${requestId} status updated to ${newStatus}`, 'success');
    loadAdminRequestsTable();
  } catch (error) {
    showToast('Failed to update status: ' + error.message, 'error');
  }
}

function getStatusBadgeClass(status) {
  switch (status) {
    case 'Approved': return 'bg-primary';
    case 'Fulfilled': return 'bg-success';
    case 'Rejected': return 'bg-danger';
    case 'Cancelled': return 'bg-secondary';
    default: return 'bg-warning text-dark';
  }
}
