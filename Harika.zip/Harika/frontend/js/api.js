/**
 * Centralized API Client, Notification Helper & Theme Engine
 * BloodLink – Connecting Donors, Blood Banks & Lives
 */

const API_BASE_URL = '/api';

// --- THEME ENGINE (LIGHT / DARK MODE PERSISTENCE) ---
function initTheme() {
  const savedTheme = localStorage.getItem('bloodlink_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcon(savedTheme);
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('bloodlink_theme', newTheme);
  updateThemeIcon(newTheme);
  showToast(`Switched to ${newTheme === 'dark' ? 'Dark' : 'Light'} Mode`, 'info');
}

function updateThemeIcon(theme) {
  const icons = document.querySelectorAll('.theme-toggle-icon');
  icons.forEach(icon => {
    if (theme === 'dark') {
      icon.className = 'bi bi-sun-fill theme-toggle-icon text-warning';
    } else {
      icon.className = 'bi bi-moon-stars-fill theme-toggle-icon text-secondary';
    }
  });
}

// Initialize theme immediately on script load
initTheme();

// --- TOKEN & SESSION MANAGEMENT ---
function getToken() {
  return localStorage.getItem('blood_bank_token');
}

function setToken(token) {
  localStorage.setItem('blood_bank_token', token);
}

function removeToken() {
  localStorage.removeItem('blood_bank_token');
  localStorage.removeItem('blood_bank_user');
}

function getCurrentUser() {
  const userStr = localStorage.getItem('blood_bank_user');
  if (!userStr) return null;
  try {
    return JSON.parse(userStr);
  } catch (e) {
    return null;
  }
}

function setCurrentUser(user) {
  localStorage.setItem('blood_bank_user', JSON.stringify(user));
}

/**
 * Core HTTP Request Wrapper
 */
async function apiRequest(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  const token = getToken();

  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config = {
    ...options,
    headers
  };

  try {
    const response = await fetch(url, config);
    const result = await response.json().catch(() => ({
      success: false,
      message: 'Invalid JSON response from server',
      error: response.statusText
    }));

    if (!response.ok) {
      if (response.status === 401 && !url.includes('/auth/login')) {
        removeToken();
        if (!window.location.pathname.includes('login.html')) {
          showToast('Session expired. Please log in again.', 'warning');
          setTimeout(() => {
            window.location.href = 'login.html';
          }, 1200);
        }
      }
      throw new Error(result.error || result.message || 'API request failed');
    }

    return result;
  } catch (error) {
    console.error(`API Error on [${options.method || 'GET'}] ${endpoint}:`, error);
    throw error;
  }
}

function apiGet(endpoint, params = {}) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, val]) => {
    if (val !== undefined && val !== null && val !== '') {
      query.append(key, val);
    }
  });
  const queryString = query.toString() ? `?${query.toString()}` : '';
  return apiRequest(`${endpoint}${queryString}`, { method: 'GET' });
}

function apiPost(endpoint, data = {}) {
  return apiRequest(endpoint, {
    method: 'POST',
    body: JSON.stringify(data)
  });
}

function apiPut(endpoint, data = {}) {
  return apiRequest(endpoint, {
    method: 'PUT',
    body: JSON.stringify(data)
  });
}

function apiDelete(endpoint) {
  return apiRequest(endpoint, {
    method: 'DELETE'
  });
}

/**
 * Toast Notification System
 */
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast-custom toast-${type}`;
  
  const iconMap = {
    success: 'bi-check-circle-fill text-success',
    error: 'bi-exclamation-triangle-fill text-danger',
    warning: 'bi-exclamation-circle-fill text-warning',
    info: 'bi-info-circle-fill text-info'
  };

  toast.innerHTML = `
    <i class="bi ${iconMap[type] || iconMap.info} fs-5"></i>
    <div style="flex-grow: 1; font-weight: 500; font-size: 0.88rem;">${message}</div>
    <button type="button" class="btn-close btn-close-sm" style="font-size: 0.75rem;" onclick="this.parentElement.remove()"></button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    if (toast.parentElement) {
      toast.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 300);
    }
  }, 4000);
}

/**
 * Loading Spinner Helper
 */
function showLoading(elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = `
    <div class="text-center py-5">
      <div class="spinner-border text-danger" role="status" style="width: 2.5rem; height: 2.5rem;">
        <span class="visually-hidden">Loading...</span>
      </div>
      <p class="mt-3 text-muted fw-semibold small">Fetching data from MySQL database, please wait...</p>
    </div>
  `;
}

/**
 * Empty State Helper
 */
function showEmptyState(elementId, message = 'No records found matching your criteria.') {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = `
    <div class="text-center py-5">
      <div class="stat-icon-wrapper stat-icon-amber mx-auto mb-3" style="width: 64px; height: 64px;">
        <i class="bi bi-inbox fs-2"></i>
      </div>
      <h5 class="fw-bold">No Records Found</h5>
      <p class="text-muted small max-w-400 mx-auto">${message}</p>
    </div>
  `;
}

/**
 * Format Date Helper
 */
function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
