/**
 * Geolocation & Leaflet.js Map Controller
 * Blood Bank and Donor Location System
 */

let mapInstance = null;
let markersLayer = null;
let userLocationMarker = null;

// Default Map Center: Hyderabad, India
const DEFAULT_COORDS = [17.385044, 78.486671];
const DEFAULT_ZOOM = 12;

/**
 * Initialize Leaflet Map
 * @param {string} mapElementId - HTML element ID for the map container
 * @param {Array<number>} center - [lat, lng] center coordinates
 * @param {number} zoom - initial zoom level
 */
function initLeafletMap(mapElementId = 'map', center = DEFAULT_COORDS, zoom = DEFAULT_ZOOM) {
  const mapContainer = document.getElementById(mapElementId);
  if (!mapContainer) return null;

  if (mapInstance) {
    mapInstance.remove();
    mapInstance = null;
  }

  mapInstance = L.map(mapElementId).setView(center, zoom);

  // Add OpenStreetMap Tile Layer
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(mapInstance);

  markersLayer = L.layerGroup().addTo(mapInstance);

  return mapInstance;
}

/**
 * Obtain current browser position via Geolocation API
 * Explicit user interaction only
 */
function requestCurrentPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        let msg = 'Failed to obtain location.';
        if (error.code === error.PERMISSION_DENIED) {
          msg = 'Location permission was denied. You can still search by city or pincode.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          msg = 'Location information is currently unavailable.';
        } else if (error.code === error.TIMEOUT) {
          msg = 'Location request timed out.';
        }
        reject(new Error(msg));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  });
}

/**
 * Custom Map Marker Icons using HTML/SVG DivIcons
 */
function createDonorIcon(bloodGroup, isAvailable = true) {
  const bgColor = isAvailable ? '#dc2626' : '#94a3b8';
  return L.divIcon({
    className: 'custom-donor-pin',
    html: `
      <div style="background: ${bgColor}; color: white; width: 34px; height: 34px; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 8px rgba(0,0,0,0.3); border: 2px solid white;">
        <span style="transform: rotate(45deg); font-weight: 800; font-size: 11px; font-family: 'Outfit', sans-serif;">${bloodGroup}</span>
      </div>
    `,
    iconSize: [34, 34],
    iconAnchor: [17, 34],
    popupAnchor: [0, -34]
  });
}

function createBloodBankIcon() {
  return L.divIcon({
    className: 'custom-bank-pin',
    html: `
      <div style="background: #0284c7; color: white; width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(2,132,199,0.4); border: 2px solid white;">
        <i class="bi bi-hospital fs-5"></i>
      </div>
    `,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -20]
  });
}

function createUserLocationIcon() {
  return L.divIcon({
    className: 'user-pulse-marker-wrapper',
    html: '<div class="user-pulse-marker"></div>',
    iconSize: [18, 18],
    iconAnchor: [9, 9]
  });
}

/**
 * Display User Location on Map
 */
function setUserMarker(lat, lng, label = 'Your Current Location') {
  if (!mapInstance || !markersLayer) return;

  if (userLocationMarker) {
    markersLayer.removeLayer(userLocationMarker);
  }

  userLocationMarker = L.marker([lat, lng], { icon: createUserLocationIcon() })
    .bindPopup(`<b>${label}</b><br><small class="text-muted">Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}</small>`);
  
  markersLayer.addLayer(userLocationMarker);
}

/**
 * Render Donors on Map
 */
function plotDonorsOnMap(donors, userCoords = null) {
  if (!mapInstance || !markersLayer) return;

  donors.forEach((donor) => {
    if (!donor.latitude || !donor.longitude) return;

    const lat = parseFloat(donor.latitude);
    const lng = parseFloat(donor.longitude);
    if (isNaN(lat) || isNaN(lng)) return;

    const isAvailable = donor.availability_status === 'Available';
    const marker = L.marker([lat, lng], {
      icon: createDonorIcon(donor.blood_group, isAvailable)
    });

    const distanceDisplay = donor.distance_km !== undefined && donor.distance_km !== null
      ? `<span class="badge bg-danger rounded-pill px-2 py-1 mb-1"><i class="bi bi-geo-alt-fill me-1"></i>${donor.distance_km} km away</span><br>`
      : '';

    const popupHtml = `
      <div class="map-popup-card" style="min-width: 190px;">
        <div class="d-flex align-items-center justify-content-between mb-1">
          <span class="badge bg-danger fs-6 fw-bold">${donor.blood_group}</span>
          <span class="badge ${isAvailable ? 'bg-success' : 'bg-secondary'} rounded-pill" style="font-size: 0.7rem;">${donor.availability_status}</span>
        </div>
        <div class="fw-bold fs-6 text-dark mt-1">${donor.full_name}</div>
        <div class="text-muted small"><i class="bi bi-geo-alt me-1"></i>${donor.city}, ${donor.pincode}</div>
        ${distanceDisplay}
        <div class="mt-2 pt-2 border-top">
          <a href="tel:${donor.phone || ''}" class="btn btn-sm btn-outline-danger w-100 py-1">
            <i class="bi bi-telephone-fill me-1"></i> Contact Donor
          </a>
        </div>
      </div>
    `;

    marker.bindPopup(popupHtml);
    markersLayer.addLayer(marker);
  });
}

/**
 * Render Blood Banks on Map
 */
function plotBloodBanksOnMap(bloodBanks, userCoords = null) {
  if (!mapInstance || !markersLayer) return;

  bloodBanks.forEach((bank) => {
    if (!bank.latitude || !bank.longitude) return;

    const lat = parseFloat(bank.latitude);
    const lng = parseFloat(bank.longitude);
    if (isNaN(lat) || isNaN(lng)) return;

    const marker = L.marker([lat, lng], {
      icon: createBloodBankIcon()
    });

    const distanceDisplay = bank.distance_km !== undefined && bank.distance_km !== null
      ? `<span class="badge bg-primary rounded-pill px-2 py-1 mb-1"><i class="bi bi-geo-alt-fill me-1"></i>${bank.distance_km} km away</span><br>`
      : '';

    const popupHtml = `
      <div class="map-popup-card" style="min-width: 210px;">
        <div class="fw-bold fs-6 text-primary mb-1"><i class="bi bi-hospital me-1"></i>${bank.bank_name}</div>
        <div class="text-muted small mb-1"><i class="bi bi-geo-alt me-1"></i>${bank.address}, ${bank.city}</div>
        <div class="text-muted small mb-1"><i class="bi bi-clock me-1"></i>${bank.opening_time.slice(0, 5)} - ${bank.closing_time.slice(0, 5)}</div>
        ${distanceDisplay}
        <div class="mt-2 pt-2 border-top d-flex gap-1">
          <a href="tel:${bank.contact_number || ''}" class="btn btn-sm btn-outline-primary flex-grow-1 py-1">
            <i class="bi bi-telephone-fill me-1"></i> Call
          </a>
          <button class="btn btn-sm btn-light border py-1" onclick="viewBloodBankDetails(${bank.blood_bank_id})">
            Details
          </button>
        </div>
      </div>
    `;

    marker.bindPopup(popupHtml);
    markersLayer.addLayer(marker);
  });
}

/**
 * Clear all plotted markers
 */
function clearMapMarkers() {
  if (markersLayer) {
    markersLayer.clearLayers();
  }
}

/**
 * Fit map bounds to encompass all plotted points
 */
function fitMapToMarkers() {
  if (!mapInstance || !markersLayer) return;
  const layers = markersLayer.getLayers();
  if (layers.length > 0) {
    const group = L.featureGroup(layers);
    mapInstance.fitBounds(group.getBounds().pad(0.15));
  }
}

/**
 * Frontend Haversine Formula (matching backend implementation)
 */
function calculateDistanceFrontend(lat1, lon1, lat2, lon2) {
  const toRad = (value) => (value * Math.PI) / 180;
  const R = 6371;

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const rLat1 = toRad(lat1);
  const rLat2 = toRad(lat2);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(rLat1) * Math.cos(rLat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}
