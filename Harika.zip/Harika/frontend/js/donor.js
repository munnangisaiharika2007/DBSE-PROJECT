/**
 * Donor Management & Search Controller
 * BloodLink – Connecting Donors, Blood Banks & Lives
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('donors-list-container')) {
    initDonorsDirectoryPage();
  }
  if (document.getElementById('donor-profile-form')) {
    initDonorProfilePage();
  }
  if (document.getElementById('admin-donors-table-body')) {
    initAdminDonorsPage();
  }
});

let allDonorsCache = [];

/**
 * -----------------------------------------------------------------------------
 * PUBLIC DONORS DIRECTORY (donors.html)
 * -----------------------------------------------------------------------------
 */
async function initDonorsDirectoryPage() {
  const container = document.getElementById('donors-list-container');
  showLoading('donors-list-container');

  try {
    const res = await apiGet('/donors');
    allDonorsCache = res.data;
    renderDonorsGrid(allDonorsCache);

    const groupFilter = document.getElementById('filter-blood-group');
    const cityFilter = document.getElementById('filter-city');
    const availFilter = document.getElementById('filter-availability');

    const handleFilterChange = () => {
      const selectedGroup = groupFilter ? groupFilter.value : 'All';
      const selectedCity = cityFilter ? cityFilter.value.trim().toLowerCase() : '';
      const selectedAvail = availFilter ? availFilter.value : 'All';

      const filtered = allDonorsCache.filter(donor => {
        const matchGroup = selectedGroup === 'All' || donor.blood_group === selectedGroup;
        const matchCity = !selectedCity || donor.city.toLowerCase().includes(selectedCity);
        const matchAvail = selectedAvail === 'All' || donor.availability_status === selectedAvail;
        return matchGroup && matchCity && matchAvail;
      });

      renderDonorsGrid(filtered);
    };

    if (groupFilter) groupFilter.addEventListener('change', handleFilterChange);
    if (cityFilter) cityFilter.addEventListener('input', handleFilterChange);
    if (availFilter) availFilter.addEventListener('change', handleFilterChange);

  } catch (error) {
    showToast('Failed to load donors: ' + error.message, 'error');
  }
}

function getAvailabilityBadge(status) {
  if (status === 'Available') return '<span class="badge-status badge-available"><i class="bi bi-check-circle-fill me-1"></i>Available</span>';
  if (status === 'Temporarily Unavailable') return '<span class="badge-status badge-temporary"><i class="bi bi-clock-history me-1"></i>Temporarily Unavailable</span>';
  return '<span class="badge-status badge-unavailable"><i class="bi bi-dash-circle-fill me-1"></i>Unavailable</span>';
}

function renderDonorsGrid(donors) {
  const container = document.getElementById('donors-list-container');
  const countEl = document.getElementById('donors-count');
  if (countEl) countEl.textContent = donors.length;

  if (donors.length === 0) {
    showEmptyState('donors-list-container', 'No voluntary donors found matching the selected filters.');
    return;
  }

  container.innerHTML = `
    <div class="row g-4">
      ${donors.map(donor => `
        <div class="col-md-6 col-lg-4">
          <div class="card card-custom h-100">
            <div class="card-body-custom d-flex flex-column">
              <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="badge bg-danger fs-5 px-3 py-1 rounded-pill">${donor.blood_group}</span>
                ${getAvailabilityBadge(donor.availability_status)}
              </div>
              <h5 class="fw-bold mb-1">${donor.full_name}</h5>
              <p class="text-muted small mb-3"><i class="bi bi-geo-alt me-1 text-danger"></i>${donor.city}, ${donor.state} (${donor.pincode})</p>
              
              <div class="bg-light p-3 rounded-3 small mb-3 mt-auto">
                <div class="d-flex justify-content-between py-1 border-bottom">
                  <span class="text-muted">Age / Gender:</span>
                  <span class="fw-semibold">${donor.age} yrs / ${donor.gender}</span>
                </div>
                <div class="d-flex justify-content-between py-1 border-bottom">
                  <span class="text-muted">Total Donations:</span>
                  <span class="badge bg-success-subtle text-success fw-bold">${donor.total_donations || 0} times</span>
                </div>
                <div class="d-flex justify-content-between py-1">
                  <span class="text-muted">Last Donated:</span>
                  <span class="fw-semibold">${formatDate(donor.last_donation_date)}</span>
                </div>
              </div>

              <div class="d-flex gap-2">
                <button class="btn btn-outline-danger btn-sm flex-grow-1 rounded-pill" onclick="openDonorDetailsModal(${donor.donor_id})">
                  <i class="bi bi-info-circle me-1"></i> Profile Details
                </button>
                <a href="tel:${donor.phone || ''}" class="btn btn-brand-primary btn-sm flex-grow-1 rounded-pill text-center">
                  <i class="bi bi-telephone-fill me-1"></i> Contact
                </a>
              </div>
            </div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

/**
 * Open Modal with Full Donor Profile & Verification Status
 */
async function openDonorDetailsModal(donorId) {
  try {
    const res = await apiGet(`/donors/${donorId}`);
    const donor = res.data;

    let modalEl = document.getElementById('donorDetailsModal');
    if (!modalEl) {
      modalEl = document.createElement('div');
      modalEl.className = 'modal fade';
      modalEl.id = 'donorDetailsModal';
      modalEl.tabIndex = -1;
      document.body.appendChild(modalEl);
    }

    modalEl.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: var(--radius-lg);">
          <div class="modal-header bg-danger text-white">
            <h5 class="modal-title fw-bold"><i class="bi bi-person-badge me-2"></i>Verified Donor Profile</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-4">
            <div class="text-center mb-4">
              <span class="badge bg-danger display-6 px-4 py-2 rounded-pill">${donor.blood_group}</span>
              <h4 class="fw-bold mt-3 mb-0">${donor.full_name}</h4>
              <p class="text-muted small">${donor.city}, ${donor.state}</p>
            </div>
            <ul class="list-group list-group-flush mb-4 small">
              <li class="list-group-item d-flex justify-content-between px-0 bg-transparent">
                <span class="text-muted">Age / Gender:</span>
                <span class="fw-semibold">${donor.age} years / ${donor.gender}</span>
              </li>
              <li class="list-group-item d-flex justify-content-between px-0 bg-transparent">
                <span class="text-muted">Availability Status:</span>
                ${getAvailabilityBadge(donor.availability_status)}
              </li>
              <li class="list-group-item d-flex justify-content-between px-0 bg-transparent">
                <span class="text-muted">Medical Screening:</span>
                <span class="badge bg-info-subtle text-info fw-bold">${donor.medical_eligibility}</span>
              </li>
              <li class="list-group-item d-flex justify-content-between px-0 bg-transparent">
                <span class="text-muted">Lifetime Donations:</span>
                <span class="fw-bold text-success">${donor.total_donations || 0} times</span>
              </li>
              <li class="list-group-item d-flex justify-content-between px-0 bg-transparent">
                <span class="text-muted">Last Donation Date:</span>
                <span class="fw-semibold">${formatDate(donor.last_donation_date)}</span>
              </li>
              <li class="list-group-item d-flex justify-content-between px-0 bg-transparent">
                <span class="text-muted">Pincode:</span>
                <span class="fw-semibold">${donor.pincode}</span>
              </li>
            </ul>
            <div class="d-grid gap-2">
              <a href="tel:${donor.phone}" class="btn btn-brand-primary rounded-pill py-2 fw-semibold">
                <i class="bi bi-telephone-fill me-2"></i> Call Donor (${donor.phone})
              </a>
              <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const bsModal = new bootstrap.Modal(modalEl);
    bsModal.show();
  } catch (error) {
    showToast('Failed to load donor details: ' + error.message, 'error');
  }
}

/**
 * -----------------------------------------------------------------------------
 * DONOR PROFILE EDIT PAGE (donor-profile.html)
 * -----------------------------------------------------------------------------
 */
async function initDonorProfilePage() {
  if (!requireAuth(['donor', 'admin'])) return;

  const form = document.getElementById('donor-profile-form');

  try {
    const res = await apiGet('/auth/me');
    const me = res.data;
    const donor = me.donorProfile;

    if (donor) {
      form.dataset.donorId = donor.donor_id;
      document.getElementById('profile-name').value = me.full_name || '';
      document.getElementById('profile-email').value = me.email || '';
      document.getElementById('profile-phone').value = donor.phone || me.phone || '';
      document.getElementById('profile-blood-group').value = donor.blood_group || 'O+';
      document.getElementById('profile-dob').value = donor.date_of_birth ? donor.date_of_birth.slice(0, 10) : '';
      document.getElementById('profile-age').value = donor.age || '';
      document.getElementById('profile-gender').value = donor.gender || 'Male';
      document.getElementById('profile-address').value = donor.address || '';
      document.getElementById('profile-city').value = donor.city || '';
      document.getElementById('profile-state').value = donor.state || '';
      document.getElementById('profile-pincode').value = donor.pincode || '';
      document.getElementById('profile-availability').value = donor.availability_status || 'Available';
      
      if (document.getElementById('profile-latitude')) {
        document.getElementById('profile-latitude').value = donor.latitude || '';
      }
      if (document.getElementById('profile-longitude')) {
        document.getElementById('profile-longitude').value = donor.longitude || '';
      }
      
      const locBadge = document.getElementById('location-status-badge');
      if (locBadge) {
        if (donor.latitude && donor.longitude) {
          locBadge.className = 'badge bg-success';
          locBadge.textContent = `Coordinates Saved (${parseFloat(donor.latitude).toFixed(4)}, ${parseFloat(donor.longitude).toFixed(4)})`;
        } else {
          locBadge.className = 'badge bg-secondary';
          locBadge.textContent = 'No coordinates saved';
        }
      }
    }

    const geoBtn = document.getElementById('btn-get-current-coords');
    if (geoBtn) {
      geoBtn.addEventListener('click', async () => {
        geoBtn.disabled = true;
        geoBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Detecting GPS...';
        try {
          const coords = await requestCurrentPosition();
          document.getElementById('profile-latitude').value = coords.latitude.toFixed(6);
          document.getElementById('profile-longitude').value = coords.longitude.toFixed(6);
          showToast('GPS coordinates acquired! Click Save Changes.', 'success');
          const locBadge = document.getElementById('location-status-badge');
          if (locBadge) {
            locBadge.className = 'badge bg-success';
            locBadge.textContent = `Captured: ${coords.latitude.toFixed(4)}, ${coords.longitude.toFixed(4)}`;
          }
        } catch (err) {
          showToast(err.message, 'warning');
        } finally {
          geoBtn.disabled = false;
          geoBtn.innerHTML = '<i class="bi bi-crosshair me-1"></i> Detect My Location';
        }
      });
    }

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const donorId = form.dataset.donorId;
      const payload = {
        blood_group: document.getElementById('profile-blood-group').value,
        date_of_birth: document.getElementById('profile-dob').value,
        age: parseInt(document.getElementById('profile-age').value, 10),
        gender: document.getElementById('profile-gender').value,
        phone: document.getElementById('profile-phone').value,
        address: document.getElementById('profile-address').value.trim(),
        city: document.getElementById('profile-city').value.trim(),
        state: document.getElementById('profile-state').value.trim(),
        pincode: document.getElementById('profile-pincode').value.trim(),
        availability_status: document.getElementById('profile-availability').value,
        latitude: document.getElementById('profile-latitude')?.value || null,
        longitude: document.getElementById('profile-longitude')?.value || null
      };

      try {
        await apiPut(`/donors/${donorId}`, payload);
        showToast('Donor profile updated successfully in MySQL!', 'success');
      } catch (err) {
        showToast('Failed to update profile: ' + err.message, 'error');
      }
    });

  } catch (error) {
    showToast('Failed to load profile data: ' + error.message, 'error');
  }
}

/**
 * -----------------------------------------------------------------------------
 * ADMIN DONOR MANAGEMENT (manage-donors.html)
 * -----------------------------------------------------------------------------
 */
async function initAdminDonorsPage() {
  if (!requireAuth(['admin'])) return;
  loadAdminDonorsTable();
}

async function loadAdminDonorsTable() {
  const tbody = document.getElementById('admin-donors-table-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-danger spinner-border-sm me-2"></div>Loading donors...</td></tr>';

  try {
    const res = await apiGet('/donors');
    const donors = res.data;

    if (donors.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">No donor records found.</td></tr>';
      return;
    }

    tbody.innerHTML = donors.map(d => `
      <tr>
        <td class="fw-semibold">#${d.donor_id}</td>
        <td>
          <div class="fw-bold">${d.full_name}</div>
          <small class="text-muted">${d.city}, ${d.pincode}</small>
        </td>
        <td><span class="badge bg-danger fs-6 px-3 py-1 rounded-pill">${d.blood_group}</span></td>
        <td>${d.age} / ${d.gender}</td>
        <td>${getAvailabilityBadge(d.availability_status)}</td>
        <td>
          <span class="badge ${d.medical_eligibility === 'Eligible' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'} fw-bold">
            ${d.medical_eligibility}
          </span>
        </td>
        <td><strong>${d.total_donations || 0}</strong> times</td>
        <td>
          <div class="d-flex gap-1">
            <button class="btn btn-sm btn-outline-primary rounded-pill px-2" onclick="openDonorDetailsModal(${d.donor_id})" title="View Details">
              <i class="bi bi-eye"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger rounded-pill px-2" onclick="deleteDonorAdmin(${d.donor_id}, '${d.full_name}')" title="Delete Donor">
              <i class="bi bi-trash"></i>
            </button>
          </div>
        </td>
      </tr>
    `).join('');
  } catch (error) {
    showToast('Failed to load donors: ' + error.message, 'error');
  }
}

async function deleteDonorAdmin(donorId, name) {
  if (!confirm(`Are you sure you want to delete donor "${name}"? This action cannot be undone.`)) {
    return;
  }
  try {
    await apiDelete(`/donors/${donorId}`);
    showToast(`Donor "${name}" deleted successfully`, 'success');
    loadAdminDonorsTable();
  } catch (error) {
    showToast('Failed to delete donor: ' + error.message, 'error');
  }
}
