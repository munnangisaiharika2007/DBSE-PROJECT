/**
 * Blood Inventory Management Controller
 * BloodLink – Connecting Donors, Blood Banks & Lives
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('inventory-table-body')) {
    initInventoryPage();
  }
});

let cachedInventory = [];

async function initInventoryPage() {
  if (!requireAuth(['admin'])) return;

  loadBloodBankDropdown();
  loadInventoryTable();

  const bankFilter = document.getElementById('filter-inv-bank');
  const groupFilter = document.getElementById('filter-inv-group');
  const statusFilter = document.getElementById('filter-inv-status');

  const handleFilter = () => {
    const bankId = bankFilter ? bankFilter.value : 'All';
    const group = groupFilter ? groupFilter.value : 'All';
    const status = statusFilter ? statusFilter.value : 'All';

    const filtered = cachedInventory.filter(item => {
      const matchBank = bankId === 'All' || String(item.blood_bank_id) === bankId;
      const matchGroup = group === 'All' || item.blood_group === group;
      const matchStatus = status === 'All' || item.stock_status === status;
      return matchBank && matchGroup && matchStatus;
    });

    renderInventoryRows(filtered);
  };

  if (bankFilter) bankFilter.addEventListener('change', handleFilter);
  if (groupFilter) groupFilter.addEventListener('change', handleFilter);
  if (statusFilter) statusFilter.addEventListener('change', handleFilter);
}

async function loadBloodBankDropdown() {
  const select = document.getElementById('filter-inv-bank');
  if (!select) return;

  try {
    const res = await apiGet('/blood-banks');
    const banks = res.data;
    select.innerHTML = '<option value="All">All Blood Banks</option>' +
      banks.map(b => `<option value="${b.blood_bank_id}">${b.bank_name} (${b.city})</option>`).join('');
  } catch (error) {
    console.error('Failed to load blood bank options', error);
  }
}

async function loadInventoryTable() {
  const tbody = document.getElementById('inventory-table-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-danger spinner-border-sm me-2"></div>Loading inventory...</td></tr>';

  try {
    const res = await apiGet('/inventory');
    cachedInventory = res.data;
    renderInventoryRows(cachedInventory);
  } catch (error) {
    showToast('Failed to load inventory: ' + error.message, 'error');
  }
}

function renderInventoryRows(items) {
  const tbody = document.getElementById('inventory-table-body');
  if (!tbody) return;

  if (items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-5 text-muted"><i class="bi bi-inbox fs-3 d-block mb-2"></i>No inventory records matching filters.</td></tr>';
    return;
  }

  tbody.innerHTML = items.map(item => {
    let badgeClass = 'badge-available';
    let meterClass = 'stock-meter-green';
    let percent = Math.min(Math.round((item.units_available / item.minimum_required_units) * 100), 100);

    if (item.stock_status === 'Critical') {
      badgeClass = 'badge-critical';
      meterClass = 'stock-meter-red';
    } else if (item.stock_status === 'Low Stock') {
      badgeClass = 'badge-temporary';
      meterClass = 'stock-meter-amber';
    } else if (item.stock_status === 'Out of Stock') {
      badgeClass = 'badge-unavailable';
      meterClass = 'stock-meter-red';
      percent = 0;
    }

    return `
      <tr>
        <td class="fw-semibold">#${item.inventory_id}</td>
        <td>
          <div class="fw-bold">${item.bank_name}</div>
          <small class="text-muted">${item.city}</small>
        </td>
        <td><span class="badge bg-danger fs-6 px-3 py-1 rounded-pill">${item.blood_group}</span></td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <span class="fw-bold fs-6 ${item.units_available < item.minimum_required_units ? 'text-danger' : 'text-success'}">${item.units_available} Units</span>
          </div>
          <div class="stock-meter-wrapper" style="width: 120px;" title="${percent}% of minimum buffer">
            <div class="stock-meter-bar ${meterClass}" style="width: ${percent}%;"></div>
          </div>
        </td>
        <td>${item.minimum_required_units} Units</td>
        <td><span class="badge-status ${badgeClass}">${item.stock_status}</span></td>
        <td>
          <button class="btn btn-sm btn-outline-primary rounded-pill px-3" onclick="openEditInventoryModal(${item.inventory_id}, '${item.bank_name.replace(/'/g, "\\'")}', '${item.blood_group}', ${item.units_available}, ${item.minimum_required_units})">
            <i class="bi bi-pencil me-1"></i> Adjust Units
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function openEditInventoryModal(invId, bankName, bloodGroup, units, minUnits) {
  let modalEl = document.getElementById('editInventoryModal');
  if (!modalEl) {
    modalEl = document.createElement('div');
    modalEl.className = 'modal fade';
    modalEl.id = 'editInventoryModal';
    modalEl.tabIndex = -1;
    document.body.appendChild(modalEl);
  }

  modalEl.innerHTML = `
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg" style="border-radius: var(--radius-lg);">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i>Update Stock Level</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <form id="edit-inventory-form" onsubmit="handleUpdateInventorySubmit(event, ${invId})">
          <div class="modal-body p-4">
            <div class="mb-3">
              <label class="form-label text-muted small">Blood Bank</label>
              <input type="text" class="form-control bg-light" value="${bankName}" readonly>
            </div>
            <div class="mb-3">
              <label class="form-label text-muted small">Blood Group</label>
              <input type="text" class="form-control bg-light" value="${bloodGroup}" readonly>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold">Units Available</label>
              <input type="number" id="edit-units-avail" class="form-control" min="0" value="${units}" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold">Minimum Required Safety Buffer</label>
              <input type="number" id="edit-min-units" class="form-control" min="1" value="${minUnits}" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-brand-primary rounded-pill px-4">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  `;

  const bsModal = new bootstrap.Modal(modalEl);
  bsModal.show();
}

async function handleUpdateInventorySubmit(event, invId) {
  event.preventDefault();
  const units_available = parseInt(document.getElementById('edit-units-avail').value, 10);
  const minimum_required_units = parseInt(document.getElementById('edit-min-units').value, 10);

  try {
    await apiPut(`/inventory/${invId}`, { units_available, minimum_required_units });
    showToast('Inventory updated successfully in MySQL!', 'success');
    
    const modalEl = document.getElementById('editInventoryModal');
    if (modalEl) {
      const bsModal = bootstrap.Modal.getInstance(modalEl);
      if (bsModal) bsModal.hide();
    }
    loadInventoryTable();
  } catch (error) {
    showToast('Failed to update inventory: ' + error.message, 'error');
  }
}
