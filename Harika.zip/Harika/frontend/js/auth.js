/**
 * Authentication and Navigation State Handler
 * BloodLink – Connecting Donors, Blood Banks & Lives
 */

document.addEventListener('DOMContentLoaded', () => {
  renderNavbarAuth();
  setupLoginForm();
  setupRegisterForm();
  updateThemeIcon(localStorage.getItem('bloodlink_theme') || 'light');
  renderUniversalFooter();
});

/**
 * Dynamically render the navigation bar with Theme Switcher and Authentication state
 */
function renderNavbarAuth() {
  const user = getCurrentUser();
  const authNav = document.getElementById('navbar-auth-section');
  if (!authNav) return;

  const currentTheme = localStorage.getItem('bloodlink_theme') || 'light';
  const themeBtnHtml = `
    <button type="button" class="btn-theme-toggle me-2" onclick="toggleTheme()" title="Toggle Dark/Light Mode">
      <i class="bi ${currentTheme === 'dark' ? 'bi-sun-fill text-warning' : 'bi-moon-stars-fill text-secondary'} theme-toggle-icon"></i>
    </button>
  `;

  if (user) {
    let dashboardUrl = 'user-dashboard.html';
    let roleBadgeClass = 'bg-info text-white';
    let roleName = 'Recipient';

    if (user.role === 'admin') {
      dashboardUrl = 'admin-dashboard.html';
      roleBadgeClass = 'bg-danger text-white';
      roleName = 'Administrator';
    } else if (user.role === 'donor') {
      dashboardUrl = 'donor-dashboard.html';
      roleBadgeClass = 'bg-success text-white';
      roleName = 'Blood Donor';
    }

    authNav.innerHTML = `
      <div class="d-flex align-items-center gap-2">
        ${themeBtnHtml}
        <a href="${dashboardUrl}" class="btn btn-outline-danger btn-sm rounded-pill px-3 fw-semibold">
          <i class="bi bi-speedometer2 me-1"></i> Dashboard
        </a>
        <div class="dropdown">
          <button class="btn btn-light btn-sm rounded-pill dropdown-toggle d-flex align-items-center gap-2 border px-3" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center" style="width: 26px; height: 26px; font-size: 0.75rem; font-weight: 700;">
              ${user.full_name ? user.full_name.charAt(0).toUpperCase() : 'U'}
            </div>
            <span class="fw-semibold text-truncate" style="max-width: 120px;">${user.full_name || 'My Account'}</span>
            <span class="badge ${roleBadgeClass} rounded-pill px-2 py-1" style="font-size: 0.65rem;">${roleName}</span>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2 p-2">
            <li><h6 class="dropdown-header text-muted small pb-1">${user.email}</h6></li>
            <li><a class="dropdown-item rounded-2 py-2" href="${dashboardUrl}"><i class="bi bi-grid me-2 text-danger"></i> My Dashboard</a></li>
            ${user.role === 'donor' ? '<li><a class="dropdown-item rounded-2 py-2" href="donor-profile.html"><i class="bi bi-person-badge me-2 text-danger"></i> Donor Profile & GPS</a></li>' : ''}
            ${user.role === 'donor' ? '<li><a class="dropdown-item rounded-2 py-2" href="donation-history.html"><i class="bi bi-clock-history me-2 text-danger"></i> Donation Records</a></li>' : ''}
            ${user.role === 'user' ? '<li><a class="dropdown-item rounded-2 py-2" href="blood-request.html"><i class="bi bi-plus-circle me-2 text-danger"></i> Request Blood</a></li>' : ''}
            ${user.role === 'user' ? '<li><a class="dropdown-item rounded-2 py-2" href="request-history.html"><i class="bi bi-clock-history me-2 text-danger"></i> Request Status Tracking</a></li>' : ''}
            <li><hr class="dropdown-divider my-1"></li>
            <li><button class="dropdown-item rounded-2 py-2 text-danger fw-semibold" onclick="handleLogout()"><i class="bi bi-box-arrow-right me-2"></i> Sign Out</button></li>
          </ul>
        </div>
      </div>
    `;
  } else {
    authNav.innerHTML = `
      <div class="d-flex align-items-center gap-2">
        ${themeBtnHtml}
        <a href="login.html" class="btn btn-outline-danger btn-sm rounded-pill px-3 fw-semibold">
          <i class="bi bi-box-arrow-in-right me-1"></i> Sign In
        </a>
        <a href="register.html" class="btn btn-brand-primary btn-sm rounded-pill px-3">
          <i class="bi bi-person-plus me-1"></i> Register
        </a>
      </div>
    `;
  }
}

/**
 * Handle Login Form Submission
 */
function setupLoginForm() {
  const form = document.getElementById('login-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Signing in...';

    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    try {
      const response = await apiPost('/auth/login', { email, password });
      setToken(response.data.token);
      setCurrentUser(response.data.user);

      showToast(`Welcome back, ${response.data.user.full_name}!`, 'success');

      setTimeout(() => {
        if (response.data.user.role === 'admin') {
          window.location.href = 'admin-dashboard.html';
        } else if (response.data.user.role === 'donor') {
          window.location.href = 'donor-dashboard.html';
        } else {
          window.location.href = 'user-dashboard.html';
        }
      }, 900);
    } catch (error) {
      showToast(error.message, 'error');
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });
}

/**
 * Handle Registration Form Submission
 */
function setupRegisterForm() {
  const form = document.getElementById('register-form');
  if (!form) return;

  const roleSelect = document.getElementById('register-role');
  const donorFields = document.getElementById('donor-extra-fields');

  if (roleSelect && donorFields) {
    roleSelect.addEventListener('change', () => {
      donorFields.style.display = roleSelect.value === 'donor' ? 'block' : 'none';
    });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Creating Account...';

    const payload = {
      full_name: document.getElementById('reg-name').value.trim(),
      email: document.getElementById('reg-email').value.trim(),
      phone: document.getElementById('reg-phone').value.trim(),
      password: document.getElementById('reg-password').value,
      role: roleSelect ? roleSelect.value : 'user'
    };

    if (payload.role === 'donor') {
      payload.blood_group = document.getElementById('reg-blood-group').value;
      payload.date_of_birth = document.getElementById('reg-dob').value;
      payload.gender = document.getElementById('reg-gender').value;
      payload.address = document.getElementById('reg-address').value.trim();
      payload.city = document.getElementById('reg-city').value.trim();
      payload.state = document.getElementById('reg-state').value.trim();
      payload.pincode = document.getElementById('reg-pincode').value.trim();
      payload.latitude = document.getElementById('reg-latitude')?.value || null;
      payload.longitude = document.getElementById('reg-longitude')?.value || null;
    }

    try {
      const response = await apiPost('/auth/register', payload);
      setToken(response.data.token);
      setCurrentUser(response.data.user);

      showToast('Account registered successfully!', 'success');

      setTimeout(() => {
        if (response.data.user.role === 'admin') {
          window.location.href = 'admin-dashboard.html';
        } else if (response.data.user.role === 'donor') {
          window.location.href = 'donor-dashboard.html';
        } else {
          window.location.href = 'user-dashboard.html';
        }
      }, 900);
    } catch (error) {
      showToast(error.message, 'error');
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });
}

/**
 * Handle Logout
 */
function handleLogout() {
  removeToken();
  showToast('You have been logged out safely.', 'info');
  setTimeout(() => {
    window.location.href = 'login.html';
  }, 700);
}

/**
 * Route Guard
 */
function requireAuth(allowedRoles = []) {
  const user = getCurrentUser();
  const token = getToken();

  if (!user || !token) {
    showToast('Please sign in to access this page.', 'warning');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 700);
    return false;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    showToast('You do not have permission to view this page.', 'error');
    setTimeout(() => {
      if (user.role === 'admin') window.location.href = 'admin-dashboard.html';
      else if (user.role === 'donor') window.location.href = 'donor-dashboard.html';
      else window.location.href = 'user-dashboard.html';
    }, 900);
    return false;
  }

  return true;
}

/**
 * Universal Footer Renderer with BloodLink Branding
 */
function renderUniversalFooter() {
  const footers = document.querySelectorAll('.footer-custom');
  footers.forEach(footer => {
    // If it's a simple footer without complex columns, style it uniformly
    const container = footer.querySelector('.container, .container-fluid');
    if (container && !footer.querySelector('.row')) {
      container.innerHTML = `
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 text-muted">
          <div class="d-flex align-items-center gap-2">
            <span class="brand-icon" style="width: 28px; height: 28px; font-size: 0.85rem;"><i class="bi bi-droplet-fill"></i></span>
            <span class="fw-bold text-secondary">BloodLink</span>
            <span class="small">&ndash; Connecting Donors, Blood Banks &amp; Lives</span>
          </div>
          <div class="small">
            &copy; 2026 DBMS Capstone Sub-Project. Real-time MySQL 8.0 &amp; Express API.
          </div>
        </div>
      `;
      container.classList.remove('text-center');
    }
  });
}

