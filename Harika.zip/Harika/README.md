# Blood Bank and Donor Location System 🩸

A complete, full-stack relational database management system (DBMS) sub-project built with **Node.js, Express.js, MySQL 8, Leaflet.js, and Vanilla HTML5/CSS3/JavaScript**.

---

## 📌 1. Project Overview

The **Blood Bank and Donor Location System** is an intelligent, location-aware healthcare platform engineered to eliminate critical delays in locating compatible blood units during medical emergencies.

It connects:
1. **Voluntary Blood Donors:** Willing individuals who register their blood type, availability, and GPS coordinates.
2. **Hospital Blood Banks & Transfusion Centres:** Licensed facilities managing regional blood inventory reserves.
3. **Patients & Recipients:** Individuals who can search nearby donors, find blood banks, and submit hospital-verified emergency requests.
4. **System Administrators:** Healthcare managers with full visibility over donors, inventory stocks, request approvals, and spatial analytics.

---

## 🚀 2. Key Features

- **Geospatial Proximity Matching:**
  - Uses the browser Geolocation API (`navigator.geolocation.getCurrentPosition()`) with explicit user consent.
  - Computes spherical distances using the **Haversine Formula** in kilometers.
  - Interactive **Leaflet.js + OpenStreetMap** visualization with custom color-coded map pins.
  - Fallback manual search by City, State, and Pincode when location permission is denied.

- **Normalized Relational MySQL 8 Database:**
  - 3rd Normal Form (3NF) relational architecture with foreign keys, cascading deletions, composite unique keys, and check constraints.
  - Full compatibility with **MySQL Workbench**.

- **Three-Tier Role-Based Access Control (RBAC):**
  - **Admin:** Dashboard analytics, manage donors, manage blood banks, update blood inventories, review & approve/fulfill blood requests, manage registered accounts.
  - **Donor:** Manage physiological profile, toggle availability (`Available` vs `Temporarily Unavailable`), update live GPS location, inspect lifetime donations.
  - **Recipient / User:** Submit blood requests with emergency tiers (`Normal`, `Urgent`, `Critical`), view live request status, locate matching donors and blood banks.

- **Real-Time Dynamic Admin Analytics:**
  - 8 real-time KPI metrics calculated live from MySQL queries.
  - 4 interactive **Chart.js** visualizations:
    - Donor blood group distribution
    - Blood inventory reserves vs minimum safety buffer
    - Monthly donation frequency trend
    - Blood request status breakdown

- **Security & Integrity:**
  - Password hashing with **bcryptjs** (salted).
  - Stateless authentication via **JSON Web Tokens (JWT)**.
  - Parameterized SQL prepared statements to eliminate SQL Injection (SQLi).
  - Centralized Express error handler and `express-validator` input sanitization.

---

## 🛠️ 3. Technology Stack

| Layer | Technologies Used |
| :--- | :--- |
| **Frontend UI** | HTML5, CSS3, Vanilla JavaScript (ES6+), Bootstrap 5 (Responsive utilities) |
| **Maps & GIS** | Leaflet.js, OpenStreetMap tile server |
| **Data Visualizations** | Chart.js |
| **Backend API** | Node.js, Express.js (REST architecture) |
| **Database** | MySQL 8.0+ (InnoDB Engine, utf8mb4) |
| **Database Driver** | `mysql2/promise` (Connection Pooling) |
| **Security** | `bcryptjs`, `jsonwebtoken` (JWT), `cors`, `dotenv` |
| **Validation** | `express-validator` |

---

## 📂 4. Project Folder Structure

```
blood-bank-system/
├── frontend/
│   ├── index.html                   # Public Homepage & Quick Search
│   ├── about.html                   # Technical DBMS Documentation
│   ├── login.html                   # JWT Login with 1-Click Demo Fill
│   ├── register.html                # User / Donor Registration with GPS capture
│   ├── donors.html                  # Public & Filterable Donors Directory
│   ├── blood-banks.html             # Authorized Blood Banks Directory
│   ├── search.html                  # Geospatial Search + Leaflet Map
│   ├── contact.html                 # Emergency Helpdesk & Coordination
│   ├── donor-dashboard.html         # Donor Dashboard & Status Toggle
│   ├── donor-profile.html           # Donor Profile & Coordinates Update
│   ├── donation-history.html        # Verified Past Donations Log
│   ├── nearby-blood-banks.html      # Proximity Locator for Nearest Banks
│   ├── user-dashboard.html          # Recipient Overview & Request Hub
│   ├── blood-request.html           # Emergency Patient Blood Request Form
│   ├── request-history.html         # User Request Tracking Log
│   ├── admin-dashboard.html         # Live MySQL Analytics & Charts
│   ├── manage-donors.html           # Admin Donor CRUD Management
│   ├── manage-blood-banks.html      # Admin Blood Bank CRUD
│   ├── blood-inventory.html         # Real-Time Inventory Stock Editor
│   ├── manage-requests.html         # Request Triage & Status Approvals
│   ├── manage-users.html            # User Accounts & Permission Roles
│   ├── css/
│   │   └── style.css                # Custom Medical Design System
│   └── js/
│       ├── api.js                   # Centralized Fetch Client & Toasts
│       ├── auth.js                  # Auth State & Route Protection Guards
│       ├── donor.js                 # Donor Directory & Profile Logic
│       ├── bloodbank.js             # Blood Bank Directory & CRUD Logic
│       ├── inventory.js             # Stock Monitoring & Updates
│       ├── requests.js              # Blood Request Submission & Triage
│       ├── location.js              # Leaflet GIS & Geolocation Helpers
│       └── dashboard.js             # Chart.js Renderers & Live Metrics
│
├── backend/
│   ├── server.js                    # Express Application & Static Server
│   ├── config/
│   │   └── db.js                    # MySQL Connection Pool & Test Verification
│   ├── controllers/
│   │   ├── authController.js        # Registration, Login, Session me
│   │   ├── donorController.js       # Donor CRUD, Search, Geolocation
│   │   ├── bloodBankController.js   # Blood Bank CRUD & Nearby Centers
│   │   ├── inventoryController.js   # Blood Stock Thresholds
│   │   ├── requestController.js     # Blood Requests & Status Transitions
│   │   ├── donationController.js    # Transactional Donation Logging
│   │   ├── userController.js        # User Administration
│   │   └── dashboardController.js   # Aggregation Queries for Analytics
│   ├── routes/                      # Modular REST Endpoint Routers
│   ├── middleware/                  # JWT Auth, Roles, Validators, Error Handler
│   ├── utils/                       # Haversine Distance & Standardized Responses
│   └── scripts/
│       └── setupDatabase.js         # Automated Schema & Seed Runner
│
├── database/
│   ├── schema.sql                   # 3NF DDL Script for MySQL Workbench
│   ├── sample_data.sql              # Realistic Indian Seed Datasets
│   └── queries.sql                  # 12 Academic Demonstration DBMS Queries
│
├── .env                             # Active Local Environment Config
├── .env.example                     # Environment Template
├── package.json                     # Node.js Dependencies & Scripts
└── README.md                        # Documentation & Setup Manual
```

---

## ⚙️ 5. Prerequisites

Before running the application, ensure the following are installed:
1. **Node.js**: v18.0.0 or higher ([Download Node.js](https://nodejs.org/))
2. **MySQL Server**: v8.0 or higher ([Download MySQL](https://dev.mysql.com/downloads/installer/))
3. **MySQL Workbench**: (Recommended for visual schema inspection)

---

## 💾 6. Database Setup

### Option A: Automated Command-Line Setup (Fastest)

1. Verify or edit your MySQL root credentials in `.env`:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=YOUR_MYSQL_PASSWORD
   DB_NAME=blood_bank_system
   DB_PORT=3306
   JWT_SECRET=super_secret_blood_bank_jwt_key_2026
   PORT=5000
   ```

2. Run the automated database initializer:
   ```bash
   npm run db:setup
   ```
   This automatically executes `database/schema.sql` and `database/sample_data.sql`.

### Option B: Manual Setup via MySQL Workbench

1. Open **MySQL Workbench** and connect to your local MySQL instance.
2. Click **File -> Open SQL Script...** and select `database/schema.sql`.
3. Click the ⚡ **Execute** button to create the `blood_bank_system` database and tables.
4. Open `database/sample_data.sql` and execute it to populate sample data.

---

## 🏃 7. Running the Application

1. Install project dependencies:
   ```bash
   npm install
   ```

2. Start the Express server:
   ```bash
   npm start
   ```

3. Open your browser and navigate to:
   ```
   http://localhost:5000
   ```
   The backend automatically serves the frontend interface and provides REST API endpoints under `/api`.

---

## 🔑 8. Demo Login Credentials

For quick evaluation and grading, sample accounts with pre-seeded data are ready to use:

| Role | Email Address | Password |
| :--- | :--- | :--- |
| **System Administrator** | `admin@bloodbank.org` | `Password123` |
| **Voluntary Blood Donor** | `rahul.sharma@gmail.com` | `Password123` |
| **Recipient / User** | `priya.patel@gmail.com` | `Password123` |

*(Tip: On the `login.html` page, click any of the 1-Click Evaluation buttons to automatically fill credentials.)*

---

## 📡 9. REST API Documentation Summary

### Authentication Endpoints
- `POST /api/auth/register` — Register a new user or donor.
- `POST /api/auth/login` — Login with email and password (returns JWT).
- `GET /api/auth/me` — Retrieve currently authenticated user session.

### Donors Endpoints
- `GET /api/donors` — Retrieve all donors with optional filters (`blood_group`, `city`, `availability_status`).
- `GET /api/donors/:id` — Retrieve donor profile and donation history.
- `GET /api/donors/search` — Search donors by blood group, location, and radius.
- `GET /api/donors/nearby` — Get nearby donors sorted by Haversine distance (`lat`, `lng`, `radius`).
- `POST /api/donors` — Create a new donor profile.
- `PUT /api/donors/:id` — Update donor profile, availability status, or GPS coordinates.
- `DELETE /api/donors/:id` — Delete donor record (Admin only).

### Blood Banks Endpoints
- `GET /api/blood-banks` — List all registered blood banks and total available units.
- `GET /api/blood-banks/:id` — Get blood bank details with full inventory breakdown.
- `GET /api/blood-banks/nearby` — Find nearby blood banks using GPS coordinates.
- `POST /api/blood-banks` — Add a new blood bank (Admin only).
- `PUT /api/blood-banks/:id` — Update blood bank details (Admin only).
- `DELETE /api/blood-banks/:id` — Delete blood bank and associated inventory (Admin only).

### Blood Inventory Endpoints
- `GET /api/inventory` — List inventory across all banks with stock status badges.
- `GET /api/inventory/:bloodBankId` — List inventory for a specific blood bank.
- `POST /api/inventory` — Create or update inventory row (Admin only).
- `PUT /api/inventory/:id` — Update stock units or minimum buffer (Admin only).
- `DELETE /api/inventory/:id` — Delete inventory row (Admin only).

### Blood Requests Endpoints
- `GET /api/requests` — Get blood requests (user sees own, admin sees all).
- `GET /api/requests/:id` — Get single request details.
- `POST /api/requests` — Submit a new blood request.
- `PUT /api/requests/:id` — Edit blood request.
- `PUT /api/requests/:id/status` — Approve, fulfill, reject, or cancel request (Admin only).
- `DELETE /api/requests/:id` — Cancel or delete request.

### Donations Endpoints
- `GET /api/donations` — Retrieve all completed donation records.
- `GET /api/donations/donor/:donorId` — Get donation history for a specific donor.
- `POST /api/donations` — Record donation (atomically increments blood bank inventory).

### Administration Endpoints
- `GET /api/dashboard/stats` — Live aggregation metrics and chart datasets.
- `GET /api/users` — List all registered user accounts.
- `PUT /api/users/:id` — Update user account details or role.
- `DELETE /api/users/:id` — Delete user account.

---

## 📊 10. Sample DBMS Demonstration Queries

Open `database/queries.sql` to examine 12 comprehensive SQL queries illustrating:
1. `SELECT` with `WHERE`, `ORDER BY`, and field projection.
2. `INNER JOIN` across 3 relational tables (`donors`, `donations`, `blood_banks`).
3. `LEFT OUTER JOIN` with `SUM()`, `COALESCE()`, and `GROUP BY`.
4. `GROUP BY` and `HAVING` clause to detect stock shortages.
5. Aggregate functions (`COUNT()`, `AVG()`, `MIN()`, `MAX()`, `SUM()`).
6. Nested Subquery using `IN` clause.
7. Trigonometric **Haversine Spherical Distance** calculation.
8. DML `INSERT INTO` with validation.
9. Atomic `UPDATE` with inventory arithmetic increment.
10. Conditional `UPDATE` with status restrictions.
11. Referential cascading `DELETE`.
12. Multi-table combined scalar subquery aggregation for executive dashboards.

---

## 🩺 11. Troubleshooting

- **Error: `Access denied for user 'root'@'localhost'`**:
  - Open `.env` and verify that `DB_PASSWORD` matches your local MySQL server password.
- **Error: `ECONNREFUSED 127.0.0.1:3306`**:
  - Ensure the MySQL service (`MySQL80`) is running. On Windows, verify in `services.msc` or PowerShell:
    ```powershell
    Get-Service -Name "MySQL80"
    ```
- **Port 5000 in use**:
  - Change `PORT=5001` in `.env` and restart the server.

---

## 📷 12. Screenshots Placeholder

*(Capture and insert screenshots here during presentation)*
1. **Home Page & Blood Group Explorer:** `[Hero Section, Blood Group Cards, Statistics]`
2. **Interactive Spatial Map:** `[Leaflet.js Map with Donor & Hospital Pins]`
3. **Donor Management:** `[Donor Profiles, Availability Status, GPS Detection]`
4. **Blood Bank & Inventory:** `[Stock Reserves & Critical Shortage Badges]`
5. **Patient Blood Request:** `[Hospital Clinical Form & Urgency Triage]`
6. **Admin Analytics Dashboard:** `[Chart.js Visualizations & Live Database Counts]`

---

© 2026 Blood Bank and Donor Location System. College DBMS Sub-Project.
