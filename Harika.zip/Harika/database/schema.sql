-- =============================================================================
-- Blood Bank and Donor Location System
-- College Database Management System (DBMS) Project
-- Schema Definition Script for MySQL 8.0+ / MySQL Workbench
-- =============================================================================

CREATE DATABASE IF NOT EXISTS blood_bank_system
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE blood_bank_system;

-- Drop tables in reverse order of foreign key dependencies if re-running
DROP TABLE IF EXISTS donations;
DROP TABLE IF EXISTS blood_requests;
DROP TABLE IF EXISTS blood_inventory;
DROP TABLE IF EXISTS blood_banks;
DROP TABLE IF EXISTS donors;
DROP TABLE IF EXISTS users;

-- -----------------------------------------------------------------------------
-- 1. USERS TABLE
-- Stores credentials and user profiles for authentication and authorization.
-- Roles: 'admin', 'donor', 'user' (recipient)
-- -----------------------------------------------------------------------------
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'donor', 'user') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. DONORS TABLE
-- 1-to-1 relationship with `users` (users.user_id = donors.user_id).
-- Stores physiological data, location coordinates, eligibility and availability.
-- -----------------------------------------------------------------------------
CREATE TABLE donors (
  donor_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  date_of_birth DATE NOT NULL,
  age INT NOT NULL,
  gender ENUM('Male', 'Female', 'Other') NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(100) NOT NULL,
  address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  pincode VARCHAR(10) NOT NULL,
  latitude DECIMAL(10, 8) NULL,
  longitude DECIMAL(11, 8) NULL,
  last_donation_date DATE NULL,
  total_donations INT NOT NULL DEFAULT 0,
  availability_status ENUM('Available', 'Temporarily Unavailable', 'Unavailable') NOT NULL DEFAULT 'Available',
  medical_eligibility ENUM('Eligible', 'Pending Verification', 'Not Eligible') NOT NULL DEFAULT 'Eligible',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_donors_user FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_donor_age CHECK (age >= 18 AND age <= 65),
  INDEX idx_donors_blood_city (blood_group, city),
  INDEX idx_donors_availability (availability_status),
  INDEX idx_donors_coords (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. BLOOD BANKS TABLE
-- Registered blood banks, hospitals, and transfusion centers with coordinates.
-- -----------------------------------------------------------------------------
CREATE TABLE blood_banks (
  blood_bank_id INT AUTO_INCREMENT PRIMARY KEY,
  bank_name VARCHAR(150) NOT NULL,
  license_number VARCHAR(100) NOT NULL UNIQUE,
  contact_number VARCHAR(20) NOT NULL,
  email VARCHAR(100) NOT NULL,
  address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  pincode VARCHAR(10) NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  opening_time TIME NOT NULL DEFAULT '08:00:00',
  closing_time TIME NOT NULL DEFAULT '20:00:00',
  emergency_available BOOLEAN NOT NULL DEFAULT TRUE,
  status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_blood_banks_city (city),
  INDEX idx_blood_banks_coords (latitude, longitude),
  INDEX idx_blood_banks_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. BLOOD INVENTORY TABLE
-- Relational 1-to-many from blood_banks.
-- Unique composite key ensures exactly one row per blood group per blood bank.
-- -----------------------------------------------------------------------------
CREATE TABLE blood_inventory (
  inventory_id INT AUTO_INCREMENT PRIMARY KEY,
  blood_bank_id INT NOT NULL,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  units_available INT NOT NULL DEFAULT 0,
  minimum_required_units INT NOT NULL DEFAULT 10,
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_inventory_bank FOREIGN KEY (blood_bank_id) REFERENCES blood_banks(blood_bank_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT uq_bank_blood_group UNIQUE (blood_bank_id, blood_group),
  CONSTRAINT chk_units_positive CHECK (units_available >= 0),
  INDEX idx_inventory_group (blood_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. BLOOD REQUESTS TABLE
-- Blood supply requests submitted by users, hospitals, and patients.
-- -----------------------------------------------------------------------------
CREATE TABLE blood_requests (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  requester_id INT NOT NULL,
  patient_name VARCHAR(100) NOT NULL,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  units_required INT NOT NULL DEFAULT 1,
  hospital_name VARCHAR(150) NOT NULL,
  hospital_address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  pincode VARCHAR(10) NOT NULL,
  emergency_level ENUM('Normal', 'Urgent', 'Critical') NOT NULL DEFAULT 'Normal',
  required_date DATE NOT NULL,
  contact_number VARCHAR(20) NOT NULL,
  additional_notes TEXT NULL,
  status ENUM('Pending', 'Approved', 'Fulfilled', 'Rejected', 'Cancelled') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_requests_user FOREIGN KEY (requester_id) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_units_req_positive CHECK (units_required > 0),
  INDEX idx_requests_status (status),
  INDEX idx_requests_emergency (emergency_level),
  INDEX idx_requests_blood_city (blood_group, city)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 6. DONATIONS TABLE
-- Tracks official donations made by donors at designated blood banks.
-- -----------------------------------------------------------------------------
CREATE TABLE donations (
  donation_id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT NOT NULL,
  blood_bank_id INT NOT NULL,
  donation_date DATE NOT NULL,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  units_donated INT NOT NULL DEFAULT 1,
  notes VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_donations_donor FOREIGN KEY (donor_id) REFERENCES donors(donor_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_donations_bank FOREIGN KEY (blood_bank_id) REFERENCES blood_banks(blood_bank_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_units_donated_pos CHECK (units_donated > 0),
  INDEX idx_donations_date (donation_date),
  INDEX idx_donations_blood (blood_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
