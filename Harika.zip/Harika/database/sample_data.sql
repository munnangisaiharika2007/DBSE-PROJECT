-- =============================================================================
-- Blood Bank and Donor Location System
-- Sample Seed Data Script (Indian locations & realistic test datasets)
-- Default password for all sample users: Password123
-- =============================================================================

USE blood_bank_system;

-- -----------------------------------------------------------------------------
-- 1. SEED USERS (16 users: 1 Admin, 10 Donors, 5 Recipients/Users)
-- -----------------------------------------------------------------------------
INSERT INTO users (user_id, full_name, email, phone, password_hash, role) VALUES
-- Admin
(1, 'System Administrator', 'admin@bloodbank.org', '+91 9876543210', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'admin'),

-- Donors (Users 2 to 11)
(2, 'Rahul Sharma', 'rahul.sharma@gmail.com', '+91 9848011223', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(3, 'Ananya Reddy', 'ananya.reddy@gmail.com', '+91 9848022334', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(4, 'Vikram Varma', 'vikram.varma@gmail.com', '+91 9848033445', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(5, 'Sneha Rao', 'sneha.rao@gmail.com', '+91 9848044556', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(6, 'Karthik Kumar', 'karthik.k@gmail.com', '+91 9848055667', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(7, 'Pooja Hegde', 'pooja.hegde@gmail.com', '+91 9848066778', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(8, 'Arjun Reddy', 'arjun.reddy@gmail.com', '+91 9848077889', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(9, 'Divya Teja', 'divya.teja@gmail.com', '+91 9848088990', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(10, 'Suresh Babu', 'suresh.babu@gmail.com', '+91 9848099001', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),
(11, 'Meera Nair', 'meera.nair@gmail.com', '+91 9848100112', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'donor'),

-- Recipients / Standard Users (Users 12 to 16)
(12, 'Priya Patel', 'priya.patel@gmail.com', '+91 9912011223', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'user'),
(13, 'Rajesh Goud', 'rajesh.goud@gmail.com', '+91 9912022334', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'user'),
(14, 'Kavitha Srinivas', 'kavitha.s@gmail.com', '+91 9912033445', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'user'),
(15, 'Manoj Kulkarni', 'manoj.k@gmail.com', '+91 9912044556', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'user'),
(16, 'Swathi Krishna', 'swathi.k@gmail.com', '+91 9912055667', '$2a$10$XocuaaUIVHLaFWeCMb9H5OgtKmzJx/EN3INisRYhQ7q9XS.FWEGN6', 'user')
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);

-- -----------------------------------------------------------------------------
-- 2. SEED DONORS (10 Donors across Hyderabad, Secunderabad, Warangal, Vijayawada, Visakhapatnam)
-- -----------------------------------------------------------------------------
INSERT INTO donors (donor_id, user_id, blood_group, date_of_birth, age, gender, phone, email, address, city, state, pincode, latitude, longitude, last_donation_date, total_donations, availability_status, medical_eligibility) VALUES
(1, 2, 'O+', '1998-05-14', 28, 'Male', '+91 9848011223', 'rahul.sharma@gmail.com', 'Flat 402, Sai Residency, Banjara Hills Rd 12', 'Hyderabad', 'Telangana', '500034', 17.415582, 78.435821, '2026-06-15', 4, 'Available', 'Eligible'),
(2, 3, 'A+', '2000-08-22', 26, 'Female', '+91 9848022334', 'ananya.reddy@gmail.com', 'Plot 55, Madhapur, Hitec City', 'Hyderabad', 'Telangana', '500081', 17.448293, 78.391487, '2026-07-20', 2, 'Available', 'Eligible'),
(3, 4, 'B+', '1995-11-03', 31, 'Male', '+91 9848033445', 'vikram.varma@gmail.com', 'H.No 12-4-88, Paradise Circle', 'Secunderabad', 'Telangana', '500003', 17.442812, 78.487541, '2026-08-10', 6, 'Available', 'Eligible'),
(4, 5, 'AB+', '1999-02-18', 27, 'Female', '+91 9848044556', 'sneha.rao@gmail.com', 'D.No 4-12-90, Subedari', 'Warangal', 'Telangana', '506001', 17.978439, 79.594055, '2026-05-02', 3, 'Available', 'Eligible'),
(5, 6, 'O-', '1994-09-30', 32, 'Male', '+91 9848055667', 'karthik.k@gmail.com', 'Flat 101, Krishna Towers, Benz Circle', 'Vijayawada', 'Andhra Pradesh', '520010', 16.506174, 80.648015, '2026-08-25', 5, 'Available', 'Eligible'),
(6, 7, 'A-', '2001-04-12', 25, 'Female', '+91 9848066778', 'pooja.hegde@gmail.com', 'Door 22-8-15, MVP Colony Sector 3', 'Visakhapatnam', 'Andhra Pradesh', '530017', 17.741215, 83.332560, '2026-04-18', 1, 'Temporarily Unavailable', 'Pending Verification'),
(7, 8, 'B-', '1997-07-09', 29, 'Male', '+91 9848077889', 'arjun.reddy@gmail.com', 'H.No 3-8-450, KPHB Colony Phase 3, Kukatpally', 'Hyderabad', 'Telangana', '500072', 17.494793, 78.399643, '2026-07-05', 3, 'Available', 'Eligible'),
(8, 9, 'AB-', '2002-10-25', 24, 'Female', '+91 9848088990', 'divya.teja@gmail.com', 'Flat 304, Green Meadows, Marredpally', 'Secunderabad', 'Telangana', '500026', 17.452140, 78.513420, '2026-03-12', 2, 'Available', 'Eligible'),
(9, 10, 'O+', '1992-01-15', 34, 'Male', '+91 9848099001', 'suresh.babu@gmail.com', 'Plot 18, Nakkalagutta, Hanamkonda', 'Warangal', 'Telangana', '506001', 17.994200, 79.572100, '2026-06-30', 8, 'Available', 'Eligible'),
(10, 11, 'A+', '1996-12-05', 30, 'Female', '+91 9848100112', 'meera.nair@gmail.com', 'Door 9-14-3, Waltair Uplands, Siripuram', 'Visakhapatnam', 'Andhra Pradesh', '530003', 17.721540, 83.315420, '2026-08-01', 4, 'Available', 'Eligible')
ON DUPLICATE KEY UPDATE blood_group=VALUES(blood_group);

-- -----------------------------------------------------------------------------
-- 3. SEED BLOOD BANKS (6 prominent blood banks with coordinates)
-- -----------------------------------------------------------------------------
INSERT INTO blood_banks (blood_bank_id, bank_name, license_number, contact_number, email, address, city, state, pincode, latitude, longitude, opening_time, closing_time, emergency_available, status) VALUES
(1, 'Red Cross Blood Bank Central', 'LIC-TEL-HYD-001', '+91 40 27633461', 'central.hyd@redcross.org', 'Red Cross Bhavan, Vidyanagar, Nallakunta', 'Hyderabad', 'Telangana', '500044', 17.399870, 78.508540, '00:00:00', '23:59:59', TRUE, 'Active'),
(2, 'Osmania General Hospital Blood Centre', 'LIC-TEL-HYD-002', '+91 40 24600121', 'bloodbank@osmania.ac.in', 'Afzal Gunj, High Court Road', 'Hyderabad', 'Telangana', '500012', 17.376820, 78.473520, '00:00:00', '23:59:59', TRUE, 'Active'),
(3, 'Apollo Transfusion Centre Secunderabad', 'LIC-TEL-SEC-003', '+91 40 27718888', 'bloodcentre@apollosekund.com', 'Regimental Bazaar, Shivaji Nagar', 'Secunderabad', 'Telangana', '500025', 17.439930, 78.501720, '08:00:00', '21:00:00', TRUE, 'Active'),
(4, 'MGM Government Hospital Blood Bank', 'LIC-TEL-WAR-004', '+91 870 2423333', 'bloodbank.mgm@telangana.gov.in', 'MGM Hospital Road, Mattewada', 'Warangal', 'Telangana', '506002', 17.971200, 79.601500, '00:00:00', '23:59:59', TRUE, 'Active'),
(5, 'Government General Hospital Blood Bank', 'LIC-AP-VIJ-005', '+91 866 2577777', 'gghbloodbank@andhra.gov.in', 'Besant Road, Governorpet', 'Vijayawada', 'Andhra Pradesh', '520002', 16.512400, 80.627800, '08:00:00', '22:00:00', TRUE, 'Active'),
(6, 'King George Hospital (KGH) Regional Blood Centre', 'LIC-AP-VIZ-006', '+91 891 2564891', 'kgh.bloodcentre@ap.nic.in', 'Collectorate Road, Maharanipeta', 'Visakhapatnam', 'Andhra Pradesh', '530002', 17.708200, 83.304500, '00:00:00', '23:59:59', TRUE, 'Active')
ON DUPLICATE KEY UPDATE bank_name=VALUES(bank_name);

-- -----------------------------------------------------------------------------
-- 4. SEED BLOOD INVENTORY (All 8 blood groups for all 6 banks = 48 records)
-- -----------------------------------------------------------------------------
INSERT INTO blood_inventory (blood_bank_id, blood_group, units_available, minimum_required_units) VALUES
-- Bank 1: Red Cross Central Hyderabad
(1, 'A+', 24, 10),
(1, 'A-', 8, 5),
(1, 'B+', 30, 10),
(1, 'B-', 6, 5),
(1, 'AB+', 12, 5),
(1, 'AB-', 3, 5),
(1, 'O+', 35, 12),
(1, 'O-', 5, 8),

-- Bank 2: Osmania General Hospital
(2, 'A+', 18, 10),
(2, 'A-', 4, 5),
(2, 'B+', 22, 10),
(2, 'B-', 3, 5),
(2, 'AB+', 9, 5),
(2, 'AB-', 2, 5),
(2, 'O+', 28, 12),
(2, 'O-', 4, 8),

-- Bank 3: Apollo Secunderabad
(3, 'A+', 15, 8),
(3, 'A-', 5, 5),
(3, 'B+', 19, 8),
(3, 'B-', 4, 5),
(3, 'AB+', 7, 5),
(3, 'AB-', 1, 4),
(3, 'O+', 21, 10),
(3, 'O-', 3, 6),

-- Bank 4: MGM Hospital Warangal
(4, 'A+', 12, 8),
(4, 'A-', 2, 5),
(4, 'B+', 16, 8),
(4, 'B-', 2, 5),
(4, 'AB+', 5, 4),
(4, 'AB-', 0, 4),
(4, 'O+', 18, 10),
(4, 'O-', 2, 5),

-- Bank 5: GGH Vijayawada
(5, 'A+', 14, 8),
(5, 'A-', 3, 5),
(5, 'B+', 15, 8),
(5, 'B-', 2, 4),
(5, 'AB+', 6, 4),
(5, 'AB-', 1, 4),
(5, 'O+', 20, 10),
(5, 'O-', 2, 5),

-- Bank 6: KGH Visakhapatnam
(6, 'A+', 16, 8),
(6, 'A-', 4, 5),
(6, 'B+', 20, 8),
(6, 'B-', 3, 5),
(6, 'AB+', 8, 4),
(6, 'AB-', 2, 4),
(6, 'O+', 25, 10),
(6, 'O-', 4, 6)
ON DUPLICATE KEY UPDATE units_available=VALUES(units_available);

-- -----------------------------------------------------------------------------
-- 5. SEED BLOOD REQUESTS (8+ realistic blood requests)
-- -----------------------------------------------------------------------------
INSERT INTO blood_requests (request_id, requester_id, patient_name, blood_group, units_required, hospital_name, hospital_address, city, state, pincode, emergency_level, required_date, contact_number, additional_notes, status) VALUES
(1, 12, 'Sunil Patel', 'O+', 2, 'KIMS Hospital', 'Minister Road, Secunderabad', 'Secunderabad', 'Telangana', '500003', 'Critical', '2026-10-04', '+91 9912011223', 'Emergency cardiac surgery scheduled tomorrow morning. Immediate units needed.', 'Pending'),
(2, 13, 'Laxmi Goud', 'B+', 1, 'Care Hospital', 'Road No 1, Banjara Hills', 'Hyderabad', 'Telangana', '500034', 'Urgent', '2026-10-05', '+91 9912022334', 'Postpartum hemorrhage case in maternity wing.', 'Approved'),
(3, 14, 'Ramana Murthy', 'AB-', 2, 'NIMS Hospital', 'Punjagutta, Somajiguda', 'Hyderabad', 'Telangana', '500082', 'Critical', '2026-10-03', '+91 9912033445', 'Accident trauma patient, rare blood group required urgently.', 'Pending'),
(4, 15, 'Suresh Kulkarni', 'A+', 3, 'Kakatiya Super Speciality Hospital', 'Nayeem Nagar, Hanamkonda', 'Warangal', 'Telangana', '506009', 'Normal', '2026-10-08', '+91 9912044556', 'Scheduled orthopedic knee replacement operation next week.', 'Approved'),
(5, 16, 'Baby of Swathi', 'O-', 1, 'Andhra Hospital', 'Heart and Brain Institute, Governorpet', 'Vijayawada', 'Andhra Pradesh', '520002', 'Critical', '2026-10-04', '+91 9912055667', 'Neonatal emergency transfusion needed urgently.', 'Pending'),
(6, 12, 'Manjula Patel', 'A-', 2, 'Apollo Health City', 'Arilova, Health City', 'Visakhapatnam', 'Andhra Pradesh', '530040', 'Urgent', '2026-10-06', '+91 9912011223', 'Severe anemia and chemotherapy support.', 'Fulfilled'),
(7, 13, 'Venkat Rao', 'B-', 1, 'Yashoda Hospital', 'Alexander Road, Secunderabad', 'Secunderabad', 'Telangana', '500003', 'Normal', '2026-10-10', '+91 9912022334', 'Planned elective dialysis procedure.', 'Approved'),
(8, 14, 'Anitha Reddy', 'AB+', 2, 'Medicover Hospital', 'Hitec City, Madhapur', 'Hyderabad', 'Telangana', '500081', 'Urgent', '2026-10-05', '+91 9912033445', 'Dengue fever with critically low platelet counts.', 'Pending')
ON DUPLICATE KEY UPDATE status=VALUES(status);

-- -----------------------------------------------------------------------------
-- 6. SEED DONATIONS (10+ donation records)
-- -----------------------------------------------------------------------------
INSERT INTO donations (donation_id, donor_id, blood_bank_id, donation_date, blood_group, units_donated, notes) VALUES
(1, 1, 1, '2026-06-15', 'O+', 1, 'Voluntary whole blood donation at Red Cross central drive'),
(2, 2, 2, '2026-07-20', 'A+', 1, 'Walk-in donation for Osmania emergency reserve'),
(3, 3, 3, '2026-08-10', 'B+', 1, 'Regular voluntary donor at Apollo Secunderabad'),
(4, 4, 4, '2026-05-02', 'AB+', 1, 'Blood donation camp organized at MGM Warangal'),
(5, 5, 5, '2026-08-25', 'O-', 1, 'Rare group emergency call donation at GGH Vijayawada'),
(6, 7, 1, '2026-07-05', 'B-', 1, 'Hyderabad IT corridor corporate blood donation drive'),
(7, 8, 3, '2026-03-12', 'AB-', 1, 'Voluntary whole blood donation at Apollo centre'),
(8, 9, 4, '2026-06-30', 'O+', 1, 'Senior donor recurring bi-annual donation at MGM'),
(9, 10, 6, '2026-08-01', 'A+', 1, 'KGH Visakhapatnam coastal health initiative drive'),
(10, 1, 2, '2026-01-10', 'O+', 1, 'New Year community blood donation drive at Osmania')
ON DUPLICATE KEY UPDATE units_donated=VALUES(units_donated);
