-- =============================================================================
-- Blood Bank and Donor Location System
-- College Database Management System (DBMS) Project
-- SQL Queries Demonstration File
-- Demonstrating: SELECT, INSERT, UPDATE, DELETE, INNER/LEFT JOIN,
-- GROUP BY, ORDER BY, HAVING, Aggregate Functions, Subqueries, Haversine Distance
-- =============================================================================

USE blood_bank_system;

-- -----------------------------------------------------------------------------
-- QUERY 1: Basic SELECT with WHERE, ORDER BY, and Field Filtering
-- Objective: Retrieve all available eligible donors of 'O+' blood group in Hyderabad.
-- DBMS Concepts: Filtering (WHERE), Sorting (ORDER BY), Projection (SELECT column list).
-- -----------------------------------------------------------------------------
SELECT 
    donor_id,
    full_name,
    blood_group,
    age,
    gender,
    phone,
    email,
    city,
    availability_status
FROM donors
WHERE blood_group = 'O+'
  AND city = 'Hyderabad'
  AND availability_status = 'Available'
  AND medical_eligibility = 'Eligible'
ORDER BY age ASC;

-- -----------------------------------------------------------------------------
-- QUERY 2: INNER JOIN across Multiple Relational Tables
-- Objective: Retrieve detailed information for all donations, including donor 
--            name, donor blood group, blood bank name, and contact details.
-- DBMS Concepts: Relational INNER JOIN on Foreign Keys (donors -> donations -> blood_banks).
-- -----------------------------------------------------------------------------
SELECT 
    d.donation_id,
    dn.full_name AS donor_name,
    dn.blood_group AS donor_blood_group,
    dn.phone AS donor_phone,
    bb.bank_name,
    bb.city AS blood_bank_city,
    d.donation_date,
    d.units_donated,
    d.notes
FROM donations d
INNER JOIN donors dn ON d.donor_id = dn.donor_id
INNER JOIN blood_banks bb ON d.blood_bank_id = bb.blood_bank_id
ORDER BY d.donation_date DESC;

-- -----------------------------------------------------------------------------
-- QUERY 3: LEFT JOIN with Aggregation and Total Inventory per Blood Bank
-- Objective: List all blood banks along with total available blood units across all blood groups.
-- DBMS Concepts: LEFT OUTER JOIN, Aggregate Function SUM(), COALESCE for NULL handling, GROUP BY.
-- -----------------------------------------------------------------------------
SELECT 
    bb.blood_bank_id,
    bb.bank_name,
    bb.city,
    bb.status,
    COALESCE(SUM(bi.units_available), 0) AS total_units_in_stock,
    COUNT(bi.inventory_id) AS groups_stocked
FROM blood_banks bb
LEFT JOIN blood_inventory bi ON bb.blood_bank_id = bi.blood_bank_id
GROUP BY bb.blood_bank_id, bb.bank_name, bb.city, bb.status
ORDER BY total_units_in_stock DESC;

-- -----------------------------------------------------------------------------
-- QUERY 4: GROUP BY and HAVING Clause for Stock Alerts
-- Objective: Identify blood banks that have critically low stock (less than minimum required)
--            for any rare negative blood group (O-, A-, B-, AB-).
-- DBMS Concepts: GROUP BY, HAVING, Multi-table filtering, Comparison predicates.
-- -----------------------------------------------------------------------------
SELECT 
    bb.bank_name,
    bb.city,
    bi.blood_group,
    bi.units_available,
    bi.minimum_required_units,
    (bi.minimum_required_units - bi.units_available) AS shortage_units
FROM blood_inventory bi
INNER JOIN blood_banks bb ON bi.blood_bank_id = bb.blood_bank_id
WHERE bi.blood_group IN ('O-', 'A-', 'B-', 'AB-')
HAVING shortage_units > 0
ORDER BY shortage_units DESC;

-- -----------------------------------------------------------------------------
-- QUERY 5: Aggregate Functions & Blood Group Distribution Across Donors
-- Objective: Summarize registered donors by blood group, average age, and total donations.
-- DBMS Concepts: COUNT(), AVG(), SUM(), MIN(), MAX(), GROUP BY.
-- -----------------------------------------------------------------------------
SELECT 
    blood_group,
    COUNT(donor_id) AS total_donors,
    ROUND(AVG(age), 1) AS average_age,
    MIN(age) AS youngest_donor,
    MAX(age) AS oldest_donor,
    SUM(total_donations) AS lifetime_donations_by_group
FROM donors
GROUP BY blood_group
ORDER BY total_donors DESC;

-- -----------------------------------------------------------------------------
-- QUERY 6: Subquery (Correlated / IN Clause)
-- Objective: Find all users who have submitted more than one blood request.
-- DBMS Concepts: Subquery with IN, Nested GROUP BY and HAVING.
-- -----------------------------------------------------------------------------
SELECT 
    u.user_id,
    u.full_name,
    u.email,
    u.phone
FROM users u
WHERE u.user_id IN (
    SELECT br.requester_id
    FROM blood_requests br
    GROUP BY br.requester_id
    HAVING COUNT(br.request_id) > 1
);

-- -----------------------------------------------------------------------------
-- QUERY 7: Haversine Spherical Distance Calculation (Geographical Spatial Search)
-- Objective: Calculate physical distance in kilometers from Banjara Hills, Hyderabad 
--            (17.415582, 78.435821) to all blood banks, sorted by nearest first.
-- DBMS Concepts: Trigonometric mathematical functions (ACOS, COS, RADIANS, SIN), Aliasing, ORDER BY.
-- Formula: 6371 * ACOS(COS(RADIANS(lat1)) * COS(RADIANS(lat2)) * COS(RADIANS(lon2) - RADIANS(lon1)) + SIN(RADIANS(lat1)) * SIN(RADIANS(lat2)))
-- -----------------------------------------------------------------------------
SELECT 
    blood_bank_id,
    bank_name,
    address,
    city,
    contact_number,
    ROUND(
        6371 * ACOS(
            COS(RADIANS(17.415582)) * 
            COS(RADIANS(latitude)) * 
            COS(RADIANS(longitude) - RADIANS(78.435821)) + 
            SIN(RADIANS(17.415582)) * 
            SIN(RADIANS(latitude))
        ), 2
    ) AS distance_km
FROM blood_banks
WHERE status = 'Active'
ORDER BY distance_km ASC;

-- -----------------------------------------------------------------------------
-- QUERY 8: INSERT Query with Parameter Validation
-- Objective: Insert a new urgent blood request from a registered user.
-- DBMS Concepts: DML INSERT INTO with explicit column mapping.
-- -----------------------------------------------------------------------------
INSERT INTO blood_requests (
    requester_id, 
    patient_name, 
    blood_group, 
    units_required, 
    hospital_name, 
    hospital_address, 
    city, 
    state, 
    pincode, 
    emergency_level, 
    required_date, 
    contact_number, 
    additional_notes, 
    status
) VALUES (
    12, 
    'Deepak Reddy', 
    'O+', 
    2, 
    'Sunshine Hospital', 
    'PG Road, Paradise', 
    'Secunderabad', 
    'Telangana', 
    '500003', 
    'Urgent', 
    DATE_ADD(CURRENT_DATE, INTERVAL 2 DAY), 
    '+91 9912011223', 
    'Scheduled bypass graft intervention.', 
    'Pending'
);

-- -----------------------------------------------------------------------------
-- QUERY 9: UPDATE Query with Atomic Inventory Increments
-- Objective: Update inventory count when a donor completes a blood donation.
-- DBMS Concepts: DML UPDATE, Arithmetic expression, Compound primary key condition.
-- -----------------------------------------------------------------------------
UPDATE blood_inventory
SET units_available = units_available + 1,
    last_updated = CURRENT_TIMESTAMP
WHERE blood_bank_id = 1 
  AND blood_group = 'O+';

-- -----------------------------------------------------------------------------
-- QUERY 10: UPDATE Blood Request Status with Status Restriction
-- Objective: Hospital Admin approves a pending request and updates its state.
-- DBMS Concepts: Conditional UPDATE with multiple WHERE predicates.
-- -----------------------------------------------------------------------------
UPDATE blood_requests
SET status = 'Approved',
    updated_at = CURRENT_TIMESTAMP
WHERE request_id = 1
  AND status = 'Pending';

-- -----------------------------------------------------------------------------
-- QUERY 11: DELETE Query with Safe Referential Cascading
-- Objective: Safely cancel or remove an old fulfilled or cancelled request.
-- DBMS Concepts: DML DELETE with exact Primary Key target.
-- -----------------------------------------------------------------------------
DELETE FROM blood_requests
WHERE request_id = 8
  AND status = 'Cancelled';

-- -----------------------------------------------------------------------------
-- QUERY 12: Complex Dashboard Aggregation Query (Combined Metrics)
-- Objective: Query total metrics for system administration in a single result set.
-- DBMS Concepts: Scalar subqueries, UNION/CROSS aggregate evaluation.
-- -----------------------------------------------------------------------------
SELECT 
    (SELECT COUNT(*) FROM users) AS total_users,
    (SELECT COUNT(*) FROM donors) AS total_donors,
    (SELECT COUNT(*) FROM donors WHERE availability_status = 'Available') AS available_donors,
    (SELECT COUNT(*) FROM blood_banks WHERE status = 'Active') AS total_blood_banks,
    (SELECT COALESCE(SUM(units_available), 0) FROM blood_inventory) AS total_units_in_stock,
    (SELECT COUNT(*) FROM blood_requests WHERE status = 'Pending') AS pending_requests,
    (SELECT COUNT(*) FROM blood_requests WHERE emergency_level = 'Critical' AND status = 'Pending') AS critical_requests,
    (SELECT COUNT(*) FROM donations) AS total_donations;
